-- Schema for Hospital Management System
Create database hospital_management_system;
USE hospital_management_system;


-- Table for Users (to store user credentials and roles)
CREATE TABLE Users (
    user_id INTEGER PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    age INTEGER CHECK (age >= 0),
    role ENUM('ADMIN', 'DOCTOR', 'RECEPTIONIST', 'STAFF', 'PATIENT') NOT NULL
);

CREATE TABLE Patients (
    patient_id VARCHAR(10) PRIMARY KEY,
    user_id INTEGER NOT NULL UNIQUE,
    gender VARCHAR(20) NOT NULL,
    contact VARCHAR(10) NOT NULL CHECK (LENGTH(contact) = 10 AND contact REGEXP '^[0-9]+$'),
    medical_history TEXT,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);

CREATE TABLE Doctors (
    doctor_id VARCHAR(10) PRIMARY KEY,
    user_id INTEGER NOT NULL UNIQUE,
    specialization VARCHAR(100) NOT NULL,
    contact VARCHAR(10) NOT NULL CHECK (LENGTH(contact) = 10 AND contact REGEXP '^[0-9]+$'),
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);

CREATE TABLE Receptionists (
    receptionist_id VARCHAR(10) PRIMARY KEY,
    user_id INTEGER NOT NULL UNIQUE,
    desk_id VARCHAR(10) NOT NULL UNIQUE,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);

CREATE TABLE Staff (
    staff_id VARCHAR(10) PRIMARY KEY,
    user_id INTEGER NOT NULL UNIQUE,
    department VARCHAR(100) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);

CREATE TABLE Appointments (
    appointment_id VARCHAR(10) PRIMARY KEY,
    patient_id VARCHAR(10) NOT NULL,
    doctor_id VARCHAR(10) NOT NULL,
    time_slot VARCHAR(50) NOT NULL,
    is_emergency BOOLEAN NOT NULL DEFAULT FALSE,
    follow_up_due_date VARCHAR(50),
    follow_up_notes TEXT,
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id) ON DELETE CASCADE
);

CREATE TABLE BillItems (
    bill_item_id INTEGER PRIMARY KEY AUTO_INCREMENT,
    appointment_id VARCHAR(10) NOT NULL,
    description TEXT NOT NULL,
    cost DECIMAL(10, 2) NOT NULL CHECK (cost >= 0),
    FOREIGN KEY (appointment_id) REFERENCES Appointments(appointment_id) ON DELETE CASCADE
);

CREATE TABLE AuditLogs (
    log_id INTEGER PRIMARY KEY AUTO_INCREMENT,
    user_id INTEGER,
    log_message TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE SET NULL
);

INSERT INTO Users (username, password, name, age, role) 
VALUES ('admin', 'admin123', 'Administrator', NULL, 'ADMIN');


-- Simplified SELECT Queries for Hospital Management System

-- 1. Retrieve all users (for authentication or user management)
SELECT * FROM Users ;

-- 2. Retrieve patient details by ID
SELECT * FROM Patients p JOIN Users u ON p.user_id = u.user_id;

-- 3. Retrieve doctor details by ID
SELECT * FROM Doctors d JOIN Users u ON d.user_id = u.user_id ;

-- 4. Retrieve receptionist details by ID
SELECT * FROM Receptionists r JOIN Users u ON r.user_id = u.user_id ;

-- 5. Retrieve staff details by ID
SELECT * FROM Staff s JOIN Users u ON s.user_id = u.user_id ;

-- 6. Retrieve all appointments
SELECT * FROM Appointments ;

-- 7. Retrieve all bill items for an appointment
SELECT * FROM BillItems ;

-- 8. Retrieve all audit logs
SELECT * FROM AuditLogs ORDER BY timestamp DESC;

-- 9. Retrieve users by role
SELECT * FROM Users 


