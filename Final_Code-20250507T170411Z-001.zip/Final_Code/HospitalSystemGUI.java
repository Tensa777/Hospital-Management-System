import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// Custom exception for hospital-specific errors
class HospitalException extends Exception {
    public HospitalException(String message) {
        super(message);
    }
}

// Enum for user roles
enum UserRole {
    ADMIN, DOCTOR, RECEPTIONIST;

    public static UserRole fromString(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Role cannot be null or empty");
        }
        try {
            return UserRole.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid role: " + name);
        }
    }
}

// Interface for entities with details
interface Detailable {
    String getDetails();
}

// Base class for Person entities
abstract class Person implements Detailable {
    protected String id;
    protected String name;
    protected String contact;

    public Person(String id, String name, String contact) {
        this.id = id;
        this.name = name;
        this.contact = contact;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}

// Patient class
class Patient extends Person {
    private int age;
    private String gender;

    public Patient(String id, String name, int age, String gender, String contact) {
        super(id, name, contact);
        this.age = age;
        this.gender = gender;
    }

    @Override
    public String getDetails() {
        return String.format("Patient ID: %s, Name: %s, Age: %d, Gender: %s, Contact: %s",
                id, name, age, gender, contact);
    }
}

// Doctor class
class Doctor extends Person {
    private String specialization;

    public Doctor(String id, String name, String specialization, String contact) {
        super(id, name, contact);
        this.specialization = specialization;
    }

    @Override
    public String getDetails() {
        return String.format("Doctor ID: %s, Name: %s, Specialization: %s, Contact: %s",
                id, name, specialization, contact);
    }
}

// Appointment class
class Appointment {
    private String id;
    private String patientId;
    private String doctorId;
    private String timeSlot;
    private boolean isEmergency;
    private List<BillItem> billItems;
    private String followUpDueDate;
    private String followUpNotes;

    public Appointment(String id, String patientId, String doctorId, String timeSlot, boolean isEmergency) {
        this.id = id;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.timeSlot = timeSlot;
        this.isEmergency = isEmergency;
        this.billItems = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public void addBillItem(BillItem item) {
        billItems.add(item);
    }

    public double getTotalBill() {
        return billItems.stream().mapToDouble(BillItem::getCost).sum();
    }

    public void setFollowUp(String dueDate, String notes) {
        this.followUpDueDate = dueDate;
        this.followUpNotes = notes;
    }
}

// BillItem class
class BillItem {
    private String description;
    private double cost;

    public BillItem(String description, double cost) {
        this.description = description;
        this.cost = cost;
    }

    public double getCost() {
        return cost;
    }
}

class HospitalSystem {
    private static HospitalSystem hms = new HospitalSystem();
    private Map<String, Patient> patients = new HashMap<>();
    private Map<String, Doctor> doctors = new HashMap<>();
    private Map<String, Appointment> appointments = new HashMap<>();
    private List<String> auditLogs = new ArrayList<>();
    private Map<String, String> userCredentials = new HashMap<>();
    private int patientCounter = 1;
    private int doctorCounter = 1;
    private int appointmentCounter = 1;

    private HospitalSystem() {
        userCredentials.put("admin:ADMIN", "admin123");
    }

    public static HospitalSystem getInstance() {
        return hms;
    }

    public boolean authenticate(String userId, String password, UserRole role) {
        String key = userId + ":" + role.name();
        return userCredentials.containsKey(key) && userCredentials.get(key).equals(password);
    }

    public String addPatient(String name, int age, String gender, String contact) throws HospitalException {
        if (contact.length() != 10 || !contact.matches("\\d+")) {
            throw new HospitalException("Invalid contact number");
        }
        String id = "P" + patientCounter++;
        Patient patient = new Patient(id, name, age, gender, contact);
        patients.put(id, patient);
        auditLogs.add(String.format("User %s added patient %s", HospitalSystemGUI.loggedInUserId, id));
        userCredentials.put(id + ":PATIENT", "pass123");
        return id;
    }

    public String addDoctor(String name, String specialization, String contact) throws HospitalException {
        if (contact.length() != 10 || !contact.matches("\\d+")) {
            throw new HospitalException("Invalid contact number");
        }
        String id = "D" + doctorCounter++;
        Doctor doctor = new Doctor(id, name, specialization, contact);
        doctors.put(id, doctor);
        auditLogs.add(String.format("User %s added doctor %s", HospitalSystemGUI.loggedInUserId, id));
        userCredentials.put(id + ":DOCTOR", "doc123");
        return id;
    }

    public String bookAppointment(String patientId, String doctorId, String slot, boolean isEmergency) throws HospitalException {
        if (!patients.containsKey(patientId)) {
            throw new HospitalException("Invalid patient ID");
        }
        if (!doctors.containsKey(doctorId)) {
            throw new HospitalException("Invalid doctor ID");
        }
        String id = "A" + appointmentCounter++;
        Appointment appointment = new Appointment(id, patientId, doctorId, slot, isEmergency);
        appointments.put(id, appointment);
        auditLogs.add(String.format("User %s booked appointment %s", HospitalSystemGUI.loggedInUserId, id));
        return id;
    }

    public void addFollowUp(String pId, String appId, String dueDate, String notes) throws HospitalException {
        if (!patients.containsKey(pId)) {
            throw new HospitalException("Invalid patient ID");
        }
        if (!appointments.containsKey(appId)) {
            throw new HospitalException("Invalid appointment ID");
        }
        Appointment appointment = appointments.get(appId);
        appointment.setFollowUp(dueDate, notes);
        auditLogs.add(String.format("User %s added follow-up for appointment %s", HospitalSystemGUI.loggedInUserId, appId));
    }

    public void addBillItem(String appointmentId, String item, double cost) throws HospitalException {
        if (!appointments.containsKey(appointmentId)) {
            throw new HospitalException("Invalid appointment ID");
        }
        Appointment appointment = appointments.get(appointmentId);
        appointment.addBillItem(new BillItem(item, cost));
        auditLogs.add(String.format("User %s added bill item to appointment %s", HospitalSystemGUI.loggedInUserId, appointmentId));
    }

    public double generateBill(String appointmentId) throws HospitalException {
        if (!appointments.containsKey(appointmentId)) {
            throw new HospitalException("Invalid appointment ID");
        }
        Appointment appointment = appointments.get(appointmentId);
        auditLogs.add(String.format("User %s generated bill for appointment %s", HospitalSystemGUI.loggedInUserId, appointmentId));
        return appointment.getTotalBill();
    }

    public Person findById(String id) {
        if (patients.containsKey(id)) return patients.get(id);
        if (doctors.containsKey(id)) return doctors.get(id);
        return null;
    }

    public List<Person> findByName(String name) {
        List<Person> results = new ArrayList<>();
        results.addAll(patients.values().stream()
                .filter(p -> p.getName().toLowerCase().contains(name.toLowerCase()))
                .collect(Collectors.toList()));
        results.addAll(doctors.values().stream()
                .filter(d -> d.getName().toLowerCase().contains(name.toLowerCase()))
                .collect(Collectors.toList()));
        return results;
    }

    public void viewAuditLogs(String userId) {
        auditLogs.forEach(System.out::println);
    }
}

public class HospitalSystemGUI {
    private HospitalSystem hms;
    private JFrame frame;
    private JPanel mainPanel;
    private JTextArea outputArea;
    static String loggedInUserId;
    static UserRole loggedInRole;

    public HospitalSystemGUI() {
        hms = HospitalSystem.getInstance();
        frame = new JFrame("Hospital Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        // Login panel
        showLoginPanel();

        frame.setVisible(true);
    }

    private void showLoginPanel() {
        JPanel loginPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        JTextField userIdField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        JTextField roleField = new JTextField(15);
        JButton loginButton = new JButton("Login");

        loginPanel.add(new JLabel("User ID:"));
        loginPanel.add(userIdField);
        loginPanel.add(new JLabel("Password:"));
        loginPanel.add(passwordField);
        loginPanel.add(new JLabel("Role (ADMIN/DOCTOR/RECEPTIONIST):"));
        loginPanel.add(roleField);
        loginPanel.add(new JLabel());
        loginPanel.add(loginButton);

        outputArea = new JTextArea(5, 30);
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        frame.getContentPane().removeAll();
        frame.add(loginPanel, BorderLayout.CENTER);
        frame.add(scrollPane, BorderLayout.SOUTH);
        frame.revalidate();
        frame.repaint();

        loginButton.addActionListener(e -> {
            String userId = userIdField.getText();
            String password = new String(passwordField.getPassword());
            String role = roleField.getText();
            try {
                UserRole userRole = UserRole.fromString(role);
                if (hms.authenticate(userId, password, userRole)) {
                    loggedInUserId = userId;
                    loggedInRole = userRole;
                    outputArea.append("Login successful!\n");
                    showMainPanel();
                } else {
                    outputArea.append("Authentication failed!\n");
                }
            } catch (IllegalArgumentException ex) {
                outputArea.append("Invalid role!\n");
            }
        });
    }

    private void showMainPanel() {
        mainPanel = new JPanel(new GridLayout(9, 1, 10, 10));
        JButton addPatientButton = new JButton("Add Patient");
        JButton addDoctorButton = new JButton("Add Doctor");
        JButton bookAppointmentButton = new JButton("Book Appointment");
        JButton addFollowUpButton = new JButton("Add Follow Up");
        JButton addBillItemButton = new JButton("Add Bill Item");
        JButton generateBillButton = new JButton("Generate Bill");
        JButton searchByIdButton = new JButton("Search by ID");
        JButton searchByNameButton = new JButton("Search by Name");
        JButton enterMultiplePatientsButton = new JButton("Enter Multiple Patients");
        JButton enterMultipleDoctorsButton = new JButton("Enter Multiple Doctors");
        JButton logoutButton = new JButton("Logout");
        JButton exitButton = new JButton("Exit");

        mainPanel.add(addPatientButton);
        mainPanel.add(addDoctorButton);
        mainPanel.add(bookAppointmentButton);
        mainPanel.add(addFollowUpButton);
        mainPanel.add(addBillItemButton);
        mainPanel.add(generateBillButton);
        mainPanel.add(searchByIdButton);
        mainPanel.add(searchByNameButton);
        mainPanel.add(enterMultiplePatientsButton);
        mainPanel.add(enterMultipleDoctorsButton);
        mainPanel.add(logoutButton);
        mainPanel.add(exitButton);

        frame.getContentPane().removeAll();
        frame.add(mainPanel, BorderLayout.CENTER);
        frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
        frame.revalidate();
        frame.repaint();

        addPatientButton.addActionListener(e -> showAddPatientPanel());
        addDoctorButton.addActionListener(e -> showAddDoctorPanel());
        bookAppointmentButton.addActionListener(e -> showBookAppointmentPanel());
        addFollowUpButton.addActionListener(e -> showAddFollowUpPanel());
        addBillItemButton.addActionListener(e -> showAddBillItemPanel());
        generateBillButton.addActionListener(e -> showGenerateBillPanel());
        searchByIdButton.addActionListener(e -> showSearchByIdPanel());
        searchByNameButton.addActionListener(e -> showSearchByNamePanel());
        enterMultiplePatientsButton.addActionListener(e -> showEnterMultiplePatientsPanel());
        enterMultipleDoctorsButton.addActionListener(e -> showEnterMultipleDoctorsPanel());
        logoutButton.addActionListener(e -> {
            loggedInUserId = null;
            loggedInRole = null;
            outputArea.append("Logged out!\n");
            showLoginPanel();
        });
        exitButton.addActionListener(e -> System.exit(0));
    }

    private void showAddPatientPanel() {
        JPanel patientPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField nameField = new JTextField(15);
        JTextField ageField = new JTextField(15);
        JTextField genderField = new JTextField(15);
        JTextField contactField = new JTextField(15);
        JButton submitButton = new JButton("Submit");
        JButton backButton = new JButton("Back");

        patientPanel.add(new JLabel("Name:"));
        patientPanel.add(nameField);
        patientPanel.add(new JLabel("Age:"));
        patientPanel.add(ageField);
        patientPanel.add(new JLabel("Gender:"));
        patientPanel.add(genderField);
        patientPanel.add(new JLabel("Contact (10 digits):"));
        patientPanel.add(contactField);
        patientPanel.add(submitButton);
        patientPanel.add(backButton);

        frame.getContentPane().removeAll();
        frame.add(patientPanel, BorderLayout.CENTER);
        frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
        frame.revalidate();
        frame.repaint();

        submitButton.addActionListener(e -> {
            try {
                String name = nameField.getText();
                int age = Integer.parseInt(ageField.getText());
                String gender = genderField.getText();
                String contact = contactField.getText();
                String patientId = hms.addPatient(name, age, gender, contact);
                outputArea.append("Patient added! ID: " + patientId + "\n");
                nameField.setText("");
                ageField.setText("");
                genderField.setText("");
                contactField.setText("");
            } catch (NumberFormatException ex) {
                outputArea.append("Invalid age!\n");
            } catch (HospitalException ex) {
                outputArea.append("Error: " + ex.getMessage() + "\n");
            }
        });

        backButton.addActionListener(e -> {
            frame.getContentPane().removeAll();
            frame.add(mainPanel, BorderLayout.CENTER);
            frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
            frame.revalidate();
            frame.repaint();
        });
    }

    private void showAddDoctorPanel() {
        JPanel doctorPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        JTextField nameField = new JTextField(15);
        JTextField specializationField = new JTextField(15);
        JTextField contactField = new JTextField(15);
        JButton submitButton = new JButton("Submit");
        JButton backButton = new JButton("Back");

        if (loggedInRole == UserRole.RECEPTIONIST) {
            outputArea.append("Permission denied!\n");
            return;
        }

        doctorPanel.add(new JLabel("Name:"));
        doctorPanel.add(nameField);
        doctorPanel.add(new JLabel("Specialization:"));
        doctorPanel.add(specializationField);
        doctorPanel.add(new JLabel("Contact (10 digits):"));
        doctorPanel.add(contactField);
        doctorPanel.add(submitButton);
        doctorPanel.add(backButton);

        frame.getContentPane().removeAll();
        frame.add(doctorPanel, BorderLayout.CENTER);
        frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
        frame.revalidate();
        frame.repaint();

        submitButton.addActionListener(e -> {
            try {
                String name = nameField.getText();
                String specialization = specializationField.getText();
                String contact = contactField.getText();
                String doctorId = hms.addDoctor(name, specialization, contact);
                outputArea.append("Doctor added! ID: " + doctorId + "\n");
                nameField.setText("");
                specializationField.setText("");
                contactField.setText("");
            } catch (HospitalException ex) {
                outputArea.append("Error: " + ex.getMessage() + "\n");
            }
        });

        backButton.addActionListener(e -> {
            frame.getContentPane().removeAll();
            frame.add(mainPanel, BorderLayout.CENTER);
            frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
            frame.revalidate();
            frame.repaint();
        });
    }

    private void showBookAppointmentPanel() {
        JPanel appointmentPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField patientIdField = new JTextField(15);
        JTextField doctorIdField = new JTextField(15);
        JTextField timeSlotField = new JTextField(15);
        JCheckBox emergencyCheckBox = new JCheckBox("Is Emergency?");
        JButton submitButton = new JButton("Submit");
        JButton backButton = new JButton("Back");

        appointmentPanel.add(new JLabel("Patient ID:"));
        appointmentPanel.add(patientIdField);
        appointmentPanel.add(new JLabel("Doctor ID:"));
        appointmentPanel.add(doctorIdField);
        appointmentPanel.add(new JLabel("Time Slot:"));
        appointmentPanel.add(timeSlotField);
        appointmentPanel.add(new JLabel());
        appointmentPanel.add(emergencyCheckBox);
        appointmentPanel.add(submitButton);
        appointmentPanel.add(backButton);

        frame.getContentPane().removeAll();
        frame.add(appointmentPanel, BorderLayout.CENTER);
        frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
        frame.revalidate();
        frame.repaint();

        submitButton.addActionListener(e -> {
            try {
                String patientId = patientIdField.getText();
                String doctorId = doctorIdField.getText();
                String timeSlot = timeSlotField.getText();
                boolean isEmergency = emergencyCheckBox.isSelected();
                String appointmentId = hms.bookAppointment(patientId, doctorId, timeSlot, isEmergency);
                outputArea.append("Appointment booked! ID: " + appointmentId + "\n");
                patientIdField.setText("");
                doctorIdField.setText("");
                timeSlotField.setText("");
                emergencyCheckBox.setSelected(false);
            } catch (HospitalException ex) {
                outputArea.append("Error: " + ex.getMessage() + "\n");
            }
        });

        backButton.addActionListener(e -> {
            frame.getContentPane().removeAll();
            frame.add(mainPanel, BorderLayout.CENTER);
            frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
            frame.revalidate();
            frame.repaint();
        });
    }

    private void showAddFollowUpPanel() {
        JPanel followUpPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField patientIdField = new JTextField(15);
        JTextField appointmentIdField = new JTextField(15);
        JTextField dueDateField = new JTextField(15);
        JTextField notesField = new JTextField(15);
        JButton submitButton = new JButton("Submit");
        JButton backButton = new JButton("Back");

        followUpPanel.add(new JLabel("Patient ID:"));
        followUpPanel.add(patientIdField);
        followUpPanel.add(new JLabel("Appointment ID:"));
        followUpPanel.add(appointmentIdField);
        followUpPanel.add(new JLabel("Due Date:"));
        followUpPanel.add(dueDateField);
        followUpPanel.add(new JLabel("Notes:"));
        followUpPanel.add(notesField);
        followUpPanel.add(submitButton);
        followUpPanel.add(backButton);

        frame.getContentPane().removeAll();
        frame.add(followUpPanel, BorderLayout.CENTER);
        frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
        frame.revalidate();
        frame.repaint();

        submitButton.addActionListener(e -> {
            try {
                String patientId = patientIdField.getText();
                String appointmentId = appointmentIdField.getText();
                String dueDate = dueDateField.getText();
                String notes = notesField.getText();
                hms.addFollowUp(patientId, appointmentId, dueDate, notes);
                outputArea.append("Follow-up added for appointment " + appointmentId + "\n");
                patientIdField.setText("");
                appointmentIdField.setText("");
                dueDateField.setText("");
                notesField.setText("");
            } catch (HospitalException ex) {
                outputArea.append("Error: " + ex.getMessage() + "\n");
            }
        });

        backButton.addActionListener(e -> {
            frame.getContentPane().removeAll();
            frame.add(mainPanel, BorderLayout.CENTER);
            frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
            frame.revalidate();
            frame.repaint();
        });
    }

    private void showAddBillItemPanel() {
        JPanel billItemPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        JTextField appointmentIdField = new JTextField(15);
        JTextField descriptionField = new JTextField(15);
        JTextField costField = new JTextField(15);
        JButton submitButton = new JButton("Submit");
        JButton backButton = new JButton("Back");

        billItemPanel.add(new JLabel("Appointment ID:"));
        billItemPanel.add(appointmentIdField);
        billItemPanel.add(new JLabel("Description:"));
        billItemPanel.add(descriptionField);
        billItemPanel.add(new JLabel("Cost:"));
        billItemPanel.add(costField);
        billItemPanel.add(submitButton);
        billItemPanel.add(backButton);

        frame.getContentPane().removeAll();
        frame.add(billItemPanel, BorderLayout.CENTER);
        frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
        frame.revalidate();
        frame.repaint();

        submitButton.addActionListener(e -> {
            try {
                String appointmentId = appointmentIdField.getText();
                String description = descriptionField.getText();
                double cost = Double.parseDouble(costField.getText());
                hms.addBillItem(appointmentId, description, cost);
                outputArea.append("Bill item added to appointment " + appointmentId + "\n");
                appointmentIdField.setText("");
                descriptionField.setText("");
                costField.setText("");
            } catch (NumberFormatException ex) {
                outputArea.append("Invalid cost!\n");
            } catch (HospitalException ex) {
                outputArea.append("Error: " + ex.getMessage() + "\n");
            }
        });

        backButton.addActionListener(e -> {
            frame.getContentPane().removeAll();
            frame.add(mainPanel, BorderLayout.CENTER);
            frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
            frame.revalidate();
            frame.repaint();
        });
    }

    private void showGenerateBillPanel() {
        JPanel billPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        JTextField appointmentIdField = new JTextField(15);
        JButton submitButton = new JButton("Generate");
        JButton backButton = new JButton("Back");

        billPanel.add(new JLabel("Appointment ID:"));
        billPanel.add(appointmentIdField);
        billPanel.add(submitButton);
        billPanel.add(backButton);

        frame.getContentPane().removeAll();
        frame.add(billPanel, BorderLayout.CENTER);
        frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
        frame.revalidate();
        frame.repaint();

        submitButton.addActionListener(e -> {
            try {
                String appointmentId = appointmentIdField.getText();
                double total = hms.generateBill(appointmentId);
                outputArea.append("Total bill for appointment " + appointmentId + ": $" + total + "\n");
                appointmentIdField.setText("");
            } catch (HospitalException ex) {
                outputArea.append("Error: " + ex.getMessage() + "\n");
            }
        });

        backButton.addActionListener(e -> {
            frame.getContentPane().removeAll();
            frame.add(mainPanel, BorderLayout.CENTER);
            frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
            frame.revalidate();
            frame.repaint();
        });
    }

    private void showSearchByIdPanel() {
        JPanel searchPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        JTextField idField = new JTextField(15);
        JButton submitButton = new JButton("Search");
        JButton backButton = new JButton("Back");

        searchPanel.add(new JLabel("ID (e.g., P1 or D1):"));
        searchPanel.add(idField);
        searchPanel.add(submitButton);
        searchPanel.add(backButton);

        frame.getContentPane().removeAll();
        frame.add(searchPanel, BorderLayout.CENTER);
        frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
        frame.revalidate();
        frame.repaint();

        submitButton.addActionListener(e -> {
            String id = idField.getText();
            Person person = hms.findById(id);
            if (person != null) {
                outputArea.append(person.getDetails() + "\n");
            } else {
                outputArea.append("No person found with ID: " + id + "\n");
            }
            idField.setText("");
        });

        backButton.addActionListener(e -> {
            frame.getContentPane().removeAll();
            frame.add(mainPanel, BorderLayout.CENTER);
            frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
            frame.revalidate();
            frame.repaint();
        });
    }

    private void showSearchByNamePanel() {
        JPanel searchPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        JTextField nameField = new JTextField(15);
        JButton submitButton = new JButton("Search");
        JButton backButton = new JButton("Back");

        searchPanel.add(new JLabel("Name:"));
        searchPanel.add(nameField);
        searchPanel.add(submitButton);
        searchPanel.add(backButton);

        frame.getContentPane().removeAll();
        frame.add(searchPanel, BorderLayout.CENTER);
        frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
        frame.revalidate();
        frame.repaint();

        submitButton.addActionListener(e -> {
            String name = nameField.getText();
            List<Person> persons = hms.findByName(name);
            if (persons.isEmpty()) {
                outputArea.append("No persons found with name: " + name + "\n");
            } else {
                outputArea.append("Found persons:\n");
                for (Person person : persons) {
                    outputArea.append(person.getDetails() + "\n");
                }
            }
            nameField.setText("");
        });

        backButton.addActionListener(e -> {
            frame.getContentPane().removeAll();
            frame.add(mainPanel, BorderLayout.CENTER);
            frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
            frame.revalidate();
            frame.repaint();
        });
    }

    private void showEnterMultiplePatientsPanel() {
        JPanel patientPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        JTextField nameField = new JTextField(15);
        JTextField ageField = new JTextField(15);
        JTextField genderField = new JTextField(15);
        JTextField contactField = new JTextField(15);
        JButton addAnotherButton = new JButton("Add Another Patient");
        JButton doneButton = new JButton("Done");

        patientPanel.add(new JLabel("Name:"));
        patientPanel.add(nameField);
        patientPanel.add(new JLabel("Age:"));
        patientPanel.add(ageField);
        patientPanel.add(new JLabel("Gender:"));
        patientPanel.add(genderField);
        patientPanel.add(new JLabel("Contact (10 digits):"));
        patientPanel.add(contactField);
        patientPanel.add(addAnotherButton);
        patientPanel.add(doneButton);

        frame.getContentPane().removeAll();
        frame.add(patientPanel, BorderLayout.CENTER);
        frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
        frame.revalidate();
        frame.repaint();

        addAnotherButton.addActionListener(e -> {
            try {
                String name = nameField.getText();
                int age = Integer.parseInt(ageField.getText());
                String gender = genderField.getText();
                String contact = contactField.getText();
                String patientId = hms.addPatient(name, age, gender, contact);
                outputArea.append("Patient added! ID: " + patientId + "\n");
                nameField.setText("");
                ageField.setText("");
                genderField.setText("");
                contactField.setText("");
            } catch (NumberFormatException ex) {
                outputArea.append("Invalid age!\n");
            } catch (HospitalException ex) {
                outputArea.append("Error: " + ex.getMessage() + "\n");
            }
        });

        doneButton.addActionListener(e -> {
            frame.getContentPane().removeAll();
            frame.add(mainPanel, BorderLayout.CENTER);
            frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
            frame.revalidate();
            frame.repaint();
        });
    }

    private void showEnterMultipleDoctorsPanel() {
        JPanel doctorPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField nameField = new JTextField(15);
        JTextField specializationField = new JTextField(15);
        JTextField contactField = new JTextField(15);
        JButton addAnotherButton = new JButton("Add Another Doctor");
        JButton doneButton = new JButton("Done");

        if (loggedInRole == UserRole.RECEPTIONIST) {
            outputArea.append("Permission denied!\n");
            return;
        }

        doctorPanel.add(new JLabel("Name:"));
        doctorPanel.add(nameField);
        doctorPanel.add(new JLabel("Specialization:"));
        doctorPanel.add(specializationField);
        doctorPanel.add(new JLabel("Contact (10 digits):"));
        doctorPanel.add(contactField);
        doctorPanel.add(addAnotherButton);
        doctorPanel.add(doneButton);

        frame.getContentPane().removeAll();
        frame.add(doctorPanel, BorderLayout.CENTER);
        frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
        frame.revalidate();
        frame.repaint();

        addAnotherButton.addActionListener(e -> {
            try {
                String name = nameField.getText();
                String specialization = specializationField.getText();
                String contact = contactField.getText();
                String doctorId = hms.addDoctor(name, specialization, contact);
                outputArea.append("Doctor added! ID: " + doctorId + "\n");
                nameField.setText("");
                specializationField.setText("");
                contactField.setText("");
            } catch (HospitalException ex) {
                outputArea.append("Error: " + ex.getMessage() + "\n");
            }
        });

        doneButton.addActionListener(e -> {
            frame.getContentPane().removeAll();
            frame.add(mainPanel, BorderLayout.CENTER);
            frame.add(new JScrollPane(outputArea), BorderLayout.SOUTH);
            frame.revalidate();
            frame.repaint();
        });
    }

    public static void main(String[] args) {
        try {
            SwingUtilities.invokeLater(() -> new HospitalSystemGUI());
        } catch (Exception e) {
            System.err.println("Failed to start GUI: " + e.getMessage());
            e.printStackTrace();
        }
    }
}