package comhms.src.hms.staff.view;

import comhms.src.hms.staff.model.Staff;
import comhms.src.hms.staff.model.Doctor;
import comhms.src.hms.staff.model.Nurse;
import comhms.src.hms.staff.model.ClinicalStaff;
import comhms.src.hms.auth.controller.UserLoginService;
import java.util.*;

public class StaffView {
    private Scanner scanner;
    private Staff staff;
    private UserLoginService loginService; // For authentication and data access
    private StaffService staffService; // Placeholder for backend logic

    // Constructor
    public StaffView(Staff staff, UserLoginService loginService) {
        this.scanner = new Scanner(System.in);
        this.staff = staff;
        this.loginService = loginService;
        this.staffService = new StaffService(); // Placeholder
    }

    // Overloaded Constructor
    public StaffView(Staff staff, UserLoginService loginService, StaffService staffService) {
        this.scanner = new Scanner(System.in);
        this.staff = staff;
        this.loginService = loginService;
        this.staffService = staffService;
    }

    // Inner Class for Menu Options
    private class MenuOption {
        private String description;
        private Runnable action;

        MenuOption(String description, Runnable action) {
            this.description = description;
            this.action = action;
        }

        void display(int index) {
            System.out.println(index + ". " + description);
        }

        void execute() {
            action.run();
        }
    }

    // Method with Object Reference
    public void displayStaffMenu(Staff staff) {
        this.staff = staff; // Update staff reference
        MenuOption[] options;
        if (staff instanceof Doctor) {
            options = new MenuOption[] {
                new MenuOption("View Assigned Schedules", this::handleViewSchedules),
                new MenuOption("Perform Clinical Task (Prescribe)", this::handlePerformClinicalTask),
                new MenuOption("Generate Consultation Report", this::handleGenerateReport),
                new MenuOption("Update Profile", this::handleUpdateProfile),
                new MenuOption("Logout", () -> System.out.println("Logging out..."))
            };
        } else if (staff instanceof Nurse) {
            options = new MenuOption[] {
                new MenuOption("View Assigned Schedules", this::handleViewSchedules),
                new MenuOption("Perform Clinical Task (Vitals/Medication)", this::handlePerformClinicalTask),
                new MenuOption("Generate Shift Report", this::handleGenerateReport),
                new MenuOption("Update Profile", this::handleUpdateProfile),
                new MenuOption("Logout", () -> System.out.println("Logging out..."))
            };
        } else {
            options = new MenuOption[] {
                new MenuOption("View Assigned Schedules", this::handleViewSchedules),
                new MenuOption("Update Profile", this::handleUpdateProfile),
                new MenuOption("Logout", () -> System.out.println("Logging out..."))
            };
        }

        while (true) {
            System.out.println("\n=== Staff Dashboard ===");
            System.out.println("Welcome, " + staff.getUsername() + " (" + staff.getSubRole() + ")");
            for (int i = 0; i < options.length; i++) {
                options[i].display(i + 1);
            }

            int choice = getValidChoice(options.length);
            if (choice == options.length) { // Logout
                options[choice - 1].execute();
                break;
            }
            options[choice - 1].execute();
        }
    }

    // Method without Object Reference (Static)
    public static String getWelcomeMessage() {
        return "Welcome to the Staff Dashboard!";
    }

    // Handle View Schedules
    private void handleViewSchedules() {
        try {
            String schedules = staff.viewAssignedSchedules(staffService.getSchedules());
            System.out.println(schedules);
        } catch (Staff.StaffAccessException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Handle Perform Clinical Task
    private void handlePerformClinicalTask() {
        if (!(staff instanceof ClinicalStaff)) {
            System.out.println("Error: Only clinical staff can perform clinical tasks.");
            return;
        }
        try {
            System.out.print("Enter Patient ID (e.g., PAT001): ");
            String patientID = scanner.nextLine();
            System.out.print("Enter Task Details (e.g., Aspirin 100mg daily): ");
            String taskDetails = scanner.nextLine();
            String result = ((ClinicalStaff) staff).performClinicalTask(patientID, taskDetails);
            System.out.println(result);
        } catch (Staff.StaffAccessException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Handle Generate Report
    private void handleGenerateReport() {
        try {
            if (staff instanceof Doctor) {
                System.out.print("Enter Patient ID (e.g., PAT001): ");
                String patientID = scanner.nextLine();
                String report = ((Doctor) staff).generateConsultationReport(staffService.getSchedules(), patientID);
                System.out.println(report);
            } else if (staff instanceof Nurse) {
                System.out.print("Enter Shift Date (e.g., 2025-05-04): ");
                String shiftDate = scanner.nextLine();
                String report = ((Nurse) staff).generateShiftReport(staffService.getSchedules(), shiftDate);
                System.out.println(report);
            } else {
                System.out.println("Error: Report generation not available for this role.");
            }
        } catch (Staff.StaffAccessException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Handle Update Profile
    private void handleUpdateProfile() {
        System.out.println("\n=== Update Profile ===");
        System.out.println("1. Update Specialization");
        System.out.println("2. Update Department");
        if (staff instanceof ClinicalStaff) {
            System.out.println("3. Update License Number");
        }
        if (staff instanceof Doctor) {
            System.out.println("4. Update Consultation Fee");
        } else if (staff instanceof Nurse) {
            System.out.println("4. Update Shift Type");
        }
        System.out.println("5. Back");
        int choice = getValidChoice(staff instanceof ClinicalStaff ? 5 : 3);

        if (choice == 5 || choice == 3 && !(staff instanceof ClinicalStaff)) return;

        try {
            if (choice == 1) {
                System.out.print("Enter New Specialization: ");
                String newSpecialization = scanner.nextLine();
                String result = staff.updateProfile(newSpecialization);
                System.out.println(result);
            } else if (choice == 2) {
                System.out.print("Enter New Department: ");
                String newDepartment = scanner.nextLine();
                String result = staff.updateProfile(staff.getSpecialization(), newDepartment);
                System.out.println(result);
            } else if (choice == 3 && staff instanceof ClinicalStaff) {
                System.out.print("Enter New License Number: ");
                String newLicense = scanner.nextLine();
                String result = ((ClinicalStaff) staff).updateCredentials(newLicense);
                System.out.println(result);
            } else if (choice == 4 && staff instanceof Doctor) {
                System.out.print("Enter New Consultation Fee: ");
                double newFee = Double.parseDouble(scanner.nextLine());
                System.out.print("Enter Reason (or press Enter to skip): ");
                String reason = scanner.nextLine();
                String result = reason.isEmpty() ? ((Doctor) staff).updateConsultationFee(newFee) : 
                                                 ((Doctor) staff).updateConsultationFee(newFee, reason);
                System.out.println(result);
            } else if (choice == 4 && staff instanceof Nurse) {
                System.out.print("Enter New Shift Type (e.g., Day/Night): ");
                String newShift = scanner.nextLine();
                System.out.print("Enter Reason (or press Enter to skip): ");
                String reason = scanner.nextLine();
                String result = reason.isEmpty() ? ((Nurse) staff).updateShiftType(newShift) : 
                                                 ((Nurse) staff).updateShiftType(newShift, reason);
                System.out.println(result);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Helper Method
    private int getValidChoice(int max) {
        while (true) {
            try {
                System.out.print("Enter choice (1-" + max + "): ");
                int choice = Integer.parseInt(scanner.nextLine());
                if (choice >= 1 && choice <= max) {
                    return choice;
                }
                System.out.println("Invalid choice! Try again.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number!");
            }
        }
    }
}

// Placeholder StaffService
class StaffService {
    public List<comhms.src.hms.admin.model.Schedule> getSchedules() {
        try {
            return Arrays.asList(
                new comhms.src.hms.admin.model.Schedule(1, 2, "2025-05-04 09:00", "2025-05-04 10:00", "Booked", "Room 101"),
                new comhms.src.hms.admin.model.Schedule(2, 3, "2025-05-04 08:00", "2025-05-04 16:00", "Booked", "Ward A")
            );
        } catch (comhms.src.hms.admin.model.Schedule.InvalidScheduleException e) {
            return new ArrayList<>();
        }
    }
}