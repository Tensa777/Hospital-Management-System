package comhms.src.hms.staff.model;

import comhms.src.hms.admin.model.Schedule;
import java.util.List;

public class Nurse extends ClinicalStaff {
    private String shiftType; // E.g., "Day", "Night"

    // Constructor
    public Nurse(int userID, String username, String password, String name, int age, 
                 String employeeID, String specialization, String department, String licenseNumber, 
                 String shiftType) {
        super(userID, username, password, "Nurse", name, age, employeeID, specialization, department, licenseNumber);
        this.shiftType = shiftType;
    }

    // Overloaded Constructor
    public Nurse(int userID, String username, String password, String name, int age, 
                 String employeeID, String specialization, String department, String licenseNumber, 
                 String shiftType, String securityQuestion, String securityAnswer) {
        super(userID, username, password, "Nurse", name, age, employeeID, specialization, department, 
              licenseNumber, securityQuestion, securityAnswer);
        this.shiftType = shiftType;
    }

    // Inner Class for Nursing Task Details
    private class NursingTaskDetails {
        private String patientID;
        private String task;

        NursingTaskDetails(String patientID, String task) {
            this.patientID = patientID;
            this.task = task;
        }

        String getTaskSummary() {
            return "Patient: " + patientID + ", Task: " + task + ", Shift: " + shiftType;
        }
    }

    // Implement Abstract Method
    @Override
    public String performClinicalTask(String patientID, String taskDetails) throws Staff.StaffAccessException {
        if (patientID == null || taskDetails == null || patientID.trim().isEmpty() || taskDetails.trim().isEmpty()) {
            throw new Staff.StaffAccessException("Patient ID and task details cannot be null or empty.");
        }
        NursingTaskDetails task = new NursingTaskDetails(patientID, taskDetails);
        return "Nurse performed: " + taskDetails + " for patient " + patientID + ". " + task.getTaskSummary();
    }

    // Method with Object Reference
    public String generateShiftReport(List<Schedule> schedules, String shiftDate) 
            throws Staff.StaffAccessException {
        if (shiftDate == null || shiftDate.trim().isEmpty()) {
            throw new Staff.StaffAccessException("Shift date cannot be null or empty.");
        }
        StringBuilder report = new StringBuilder("Shift Report for Nurse: " + getUsername() + " on " + shiftDate + "\n");
        report.append("Shift Type: ").append(shiftType).append("\n");
        report.append("Specialization: ").append(getSpecialization()).append("\n");
        report.append("Assigned Schedules:\n");
        boolean hasSchedules = false;
        for (Schedule schedule : schedules) {
            if (schedule.getStaffID() == getUserID()) {
                report.append(schedule.toString()).append("\n");
                hasSchedules = true;
            }
        }
        if (!hasSchedules) {
            report.append("No schedules assigned.");
        }
        return report.toString();
    }

    // Method without Object Reference (Static)
    public static String getNurseRoleDescription() {
        return "Nurse: Records patient vitals, administers medications, and generates shift reports.";
    }

    // Overloaded Method: Update Shift Type
    public String updateShiftType(String newShiftType) throws Staff.StaffAccessException {
        if (newShiftType == null || newShiftType.trim().isEmpty()) {
            throw new Staff.StaffAccessException("Shift type cannot be empty.");
        }
        this.shiftType = newShiftType;
        NursingTaskDetails task = new NursingTaskDetails("N/A", "N/A");
        return "Shift type updated: " + task.getTaskSummary();
    }

    // Overloaded Method: Update Shift Type with Reason
    public String updateShiftType(String newShiftType, String reason) throws Staff.StaffAccessException {
        if (newShiftType == null || newShiftType.trim().isEmpty()) {
            throw new Staff.StaffAccessException("Shift type cannot be empty.");
        }
        if (reason == null || reason.trim().isEmpty()) {
            throw new Staff.StaffAccessException("Reason cannot be empty.");
        }
        this.shiftType = newShiftType;
        NursingTaskDetails task = new NursingTaskDetails("N/A", "N/A");
        return "Shift type updated: " + task.getTaskSummary() + " (Reason: " + reason + ")";
    }

    // Getters and Setters
    public String getShiftType() { return shiftType; }
    public void setShiftType(String shiftType) { this.shiftType = shiftType; }

    // Override toString
    @Override
    public String toString() {
        NursingTaskDetails task = new NursingTaskDetails("N/A", "N/A");
        return "Nurse [Username=" + getUsername() + ", EmployeeID=" + getEmployeeID() + 
               ", Specialization=" + getSpecialization() + ", Department=" + getDepartment() + 
               ", LicenseNumber=" + getLicenseNumber() + ", ShiftType=" + shiftType + 
               ", Details=" + task.getTaskSummary() + "]";
    }
}