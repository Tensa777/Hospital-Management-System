package comhms.src.hms.staff.model;

import comhms.src.hms.auth.model.UserLogin;
import comhms.src.hms.admin.model.Schedule;
import java.util.List;

public class Staff extends UserLogin {
    private String employeeID; // E.g., EMP0001
    private String specialization; // E.g., "Cardiology", "General Nursing"
    private String department; // E.g., "Medical", "Surgical"

    // Constructor
    public Staff(int userID, String username, String password, String subRole, String name, int age, 
                 String employeeID, String specialization, String department) {
        super(userID, username, password, "Staff", subRole, name, age, department, department);
        this.employeeID = employeeID;
        this.specialization = specialization;
        this.department = department;
    }

    // Overloaded Constructor
    public Staff(int userID, String username, String password, String subRole, String name, int age, 
                 String employeeID, String specialization, String department, String securityQuestion, 
                 String securityAnswer) {
        super(userID, username, password, "Staff", subRole, name, age, securityQuestion, securityAnswer);
        this.employeeID = employeeID;
        this.specialization = specialization;
        this.department = department;
    }

    // Inner Class for Staff Profile
    private class StaffProfile {
        private String title;
        private String contactInfo;

        StaffProfile(String title, String contactInfo) {
            this.title = title;
            this.contactInfo = contactInfo;
        }

        String getProfileSummary() {
            return "Title: " + title + ", Contact: " + contactInfo;
        }
    }

    // Method with Object Reference
    public String viewAssignedSchedules(List<Schedule> schedules) throws StaffAccessException {
        if (schedules == null) {
            throw new StaffAccessException("Schedule list cannot be null.");
        }
        StringBuilder result = new StringBuilder("Assigned Schedules for " + getUsername() + ":\n");
        boolean hasSchedules = false;
        for (Schedule schedule : schedules) {
            if (schedule.getStaffID() == getUserID()) {
                result.append(schedule.toString()).append("\n");
                hasSchedules = true;
            }
        }
        if (!hasSchedules) {
            result.append("No schedules assigned.");
        }
        return result.toString();
    }

    // Method without Object Reference (Static)
    public static String getStaffRoleDescription() {
        return "Staff: Provides medical or support services, such as doctors or nurses.";
    }

    // Overloaded Method: Update Profile (Specialization)
    public String updateProfile(String newSpecialization) throws StaffAccessException {
        if (newSpecialization == null || newSpecialization.trim().isEmpty()) {
            throw new StaffAccessException("Specialization cannot be empty.");
        }
        this.specialization = newSpecialization;
        StaffProfile profile = new StaffProfile(getSubRole(), "N/A");
        return "Profile updated: " + profile.getProfileSummary() + ", Specialization: " + newSpecialization;
    }

    // Overloaded Method: Update Profile (Specialization and Department)
    public String updateProfile(String newSpecialization, String newDepartment) throws StaffAccessException {
        if (newSpecialization == null || newSpecialization.trim().isEmpty() || 
            newDepartment == null || newDepartment.trim().isEmpty()) {
            throw new StaffAccessException("Specialization and department cannot be empty.");
        }
        this.specialization = newSpecialization;
        this.department = newDepartment;
        StaffProfile profile = new StaffProfile(getSubRole(), "N/A");
        return "Profile updated: " + profile.getProfileSummary() + ", Specialization: " + newSpecialization + 
               ", Department: " + newDepartment;
    }

    // User Defined Exception
    public static class StaffAccessException extends Exception {
        public StaffAccessException(String message) {
            super(message);
        }
    }

    // Getters and Setters
    public String getEmployeeID() { return employeeID; }
    public String getSpecialization() { return specialization; }
    public String getDepartment() { return department; }
    public void setEmployeeID(String employeeID) { this.employeeID = employeeID; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }
    public void setDepartment(String department) { this.department = department; }

    // Override toString
    @Override
    public String toString() {
        StaffProfile profile = new StaffProfile(getSubRole(), "N/A");
        return "Staff [Username=" + getUsername() + ", EmployeeID=" + employeeID + 
               ", Specialization=" + specialization + ", Department=" + department + 
               ", Profile=" + profile.getProfileSummary() + "]";
    }
}