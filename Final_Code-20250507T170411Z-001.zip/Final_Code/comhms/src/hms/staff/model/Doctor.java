package comhms.src.hms.staff.model;

import comhms.src.hms.admin.model.Schedule;
import java.util.List;

public class Doctor extends ClinicalStaff {
    private double consultationFee; // E.g., 100.0 (in USD)

    // Constructor
    public Doctor(int userID, String username, String password, String name, int age, 
                  String employeeID, String specialization, String department, String licenseNumber, 
                  double consultationFee) {
        super(userID, username, password, "Doctor", name, age, employeeID, specialization, department, licenseNumber);
        this.consultationFee = consultationFee;
    }

    // Overloaded Constructor
    public Doctor(int userID, String username, String password, String name, int age, 
                  String employeeID, String specialization, String department, String licenseNumber, 
                  double consultationFee, String securityQuestion, String securityAnswer) {
        super(userID, username, password, "Doctor", name, age, employeeID, specialization, department, 
              licenseNumber, securityQuestion, securityAnswer);
        this.consultationFee = consultationFee;
    }

    // Inner Class for Consultation Details
    private class ConsultationDetails {
        private String patientID;
        private String prescription;

        ConsultationDetails(String patientID, String prescription) {
            this.patientID = patientID;
            this.prescription = prescription;
        }

        String getConsultationSummary() {
            return "Patient: " + patientID + ", Prescription: " + prescription + ", Fee: $" + consultationFee;
        }
    }

    // Implement Abstract Method
    @Override
    public String performClinicalTask(String patientID, String taskDetails) throws Staff.StaffAccessException {
        if (patientID == null || taskDetails == null || patientID.trim().isEmpty() || taskDetails.trim().isEmpty()) {
            throw new Staff.StaffAccessException("Patient ID and task details cannot be null or empty.");
        }
        ConsultationDetails consultation = new ConsultationDetails(patientID, taskDetails);
        return "Doctor prescribed: " + taskDetails + " for patient " + patientID + ". " + 
               consultation.getConsultationSummary();
    }

    // Method with Object Reference
    public String generateConsultationReport(List<Schedule> schedules, String patientID) 
            throws Staff.StaffAccessException {
        if (patientID == null || patientID.trim().isEmpty()) {
            throw new Staff.StaffAccessException("Patient ID cannot be null or empty.");
        }
        StringBuilder report = new StringBuilder("Consultation Report for Patient: " + patientID + "\n");
        report.append("Doctor: ").append(getUsername()).append(" (").append(getSpecialization()).append(")\n");
        report.append("Consultation Fee: $").append(consultationFee).append("\n");
        report.append("Assigned Schedules:\n");
        boolean hasSchedules = false;
        for (Schedule schedule : schedules) {
            if (schedule.getStaffID() == getUserID()) {
                report.append(schedule.toString()).append("\n");
                hasSchedules = true;
            }
        }
        if (!hasSchedules) {
            report.append("No schedules assigned.");
        }
        return report.toString();
    }

    // Method without Object Reference (Static)
    public static String getDoctorRoleDescription() {
        return "Doctor: Diagnoses patients, prescribes medications, and generates consultation reports.";
    }

    // Overloaded Method: Update Consultation Fee
    public String updateConsultationFee(double newFee) throws Staff.StaffAccessException {
        if (newFee < 0) {
            throw new Staff.StaffAccessException("Consultation fee cannot be negative.");
        }
        this.consultationFee = newFee;
        ConsultationDetails consultation = new ConsultationDetails("N/A", "N/A");
        return "Consultation fee updated: " + consultation.getConsultationSummary();
    }

    // Overloaded Method: Update Consultation Fee with Reason
    public String updateConsultationFee(double newFee, String reason) throws Staff.StaffAccessException {
        if (newFee < 0) {
            throw new Staff.StaffAccessException("Consultation fee cannot be negative.");
        }
        if (reason == null || reason.trim().isEmpty()) {
            throw new Staff.StaffAccessException("Reason cannot be empty.");
        }
        this.consultationFee = newFee;
        ConsultationDetails consultation = new ConsultationDetails("N/A", "N/A");
        return "Consultation fee updated: " + consultation.getConsultationSummary() + " (Reason: " + reason + ")";
    }

    // Getters and Setters
    public double getConsultationFee() { return consultationFee; }
    public void setConsultationFee(double consultationFee) { this.consultationFee = consultationFee; }

    // Override toString
    @Override
    public String toString() {
        ConsultationDetails consultation = new ConsultationDetails("N/A", "N/A");
        return "Doctor [Username=" + getUsername() + ", EmployeeID=" + getEmployeeID() + 
               ", Specialization=" + getSpecialization() + ", Department=" + getDepartment() + 
               ", LicenseNumber=" + getLicenseNumber() + ", ConsultationFee=$" + consultationFee + 
               ", Details=" + consultation.getConsultationSummary() + "]";
    }
}