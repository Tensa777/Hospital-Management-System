package comhms.src.hms.staff.model;

import comhms.src.hms.admin.model.Schedule;
import java.util.List;

public abstract class ClinicalStaff extends Staff {
    private String licenseNumber; // E.g., LIC12345

    // Constructor
    public ClinicalStaff(int userID, String username, String password, String subRole, String name, int age, 
                         String employeeID, String specialization, String department, String licenseNumber) {
        super(userID, username, password, subRole, name, age, employeeID, specialization, department);
        this.licenseNumber = licenseNumber;
    }

    // Overloaded Constructor
    public ClinicalStaff(int userID, String username, String password, String subRole, String name, int age, 
                         String employeeID, String specialization, String department, String licenseNumber, 
                         String securityQuestion, String securityAnswer) {
        super(userID, username, password, subRole, name, age, employeeID, specialization, department, 
              securityQuestion, securityAnswer);
        this.licenseNumber = licenseNumber;
    }

    // Inner Class for Clinical Credentials
    private class ClinicalCredentials {
        private String credentialType;
        private String issuer;

        ClinicalCredentials(String credentialType, String issuer) {
            this.credentialType = credentialType;
            this.issuer = issuer;
        }

        String getCredentialSummary() {
            return "Credential: " + credentialType + ", Issued by: " + issuer;
        }
    }

    // Abstract Method
    public abstract String performClinicalTask(String patientID, String taskDetails) throws Staff.StaffAccessException;

    // Method with Object Reference
    public String validateLicense(List<Schedule> schedules) throws Staff.StaffAccessException {
        if (licenseNumber == null || licenseNumber.trim().isEmpty()) {
            throw new Staff.StaffAccessException("Invalid license number.");
        }
        ClinicalCredentials creds = new ClinicalCredentials("Medical License", "State Board");
        StringBuilder result = new StringBuilder("License Valid: " + licenseNumber + ", " + creds.getCredentialSummary() + "\n");
        result.append("Assigned Schedules:\n");
        boolean hasSchedules = false;
        for (Schedule schedule : schedules) {
            if (schedule.getStaffID() == getUserID()) {
                result.append(schedule.toString()).append("\n");
                hasSchedules = true;
            }
        }
        if (!hasSchedules) {
            result.append("No schedules assigned.");
        }
        return result.toString();
    }

    // Method without Object Reference (Static)
    public static String getClinicalStaffRoleDescription() {
        return "ClinicalStaff: Performs clinical tasks such as prescribing or recording vitals.";
    }

    // Overloaded Method: Update Credentials (License Number)
    public String updateCredentials(String newLicenseNumber) throws Staff.StaffAccessException {
        if (newLicenseNumber == null || newLicenseNumber.trim().isEmpty()) {
            throw new Staff.StaffAccessException("License number cannot be empty.");
        }
        this.licenseNumber = newLicenseNumber;
        ClinicalCredentials creds = new ClinicalCredentials("Medical License", "State Board");
        return "Credentials updated: " + creds.getCredentialSummary() + ", License: " + newLicenseNumber;
    }

    // Overloaded Method: Update Credentials (License Number and Issuer)
    public String updateCredentials(String newLicenseNumber, String issuer) throws Staff.StaffAccessException {
        if (newLicenseNumber == null || newLicenseNumber.trim().isEmpty() || 
            issuer == null || issuer.trim().isEmpty()) {
            throw new Staff.StaffAccessException("License number and issuer cannot be empty.");
        }
        this.licenseNumber = newLicenseNumber;
        ClinicalCredentials creds = new ClinicalCredentials("Medical License", issuer);
        return "Credentials updated: " + creds.getCredentialSummary() + ", License: " + newLicenseNumber;
    }

    // Getters and Setters
    public String getLicenseNumber() { return licenseNumber; }
    public void setLicenseNumber(String licenseNumber) { this.licenseNumber = licenseNumber; }

    // Override toString
    @Override
    public String toString() {
        ClinicalCredentials creds = new ClinicalCredentials("Medical License", "State Board");
        return "ClinicalStaff [Username=" + getUsername() + ", EmployeeID=" + getEmployeeID() + 
               ", Specialization=" + getSpecialization() + ", Department=" + getDepartment() + 
               ", LicenseNumber=" + licenseNumber + ", Credentials=" + creds.getCredentialSummary() + "]";
    }
}