package comhms.src.hms.staff.controller;

import comhms.src.hms.staff.model.Staff;
import comhms.src.hms.staff.model.ClinicalStaff;
import comhms.src.hms.staff.model.Doctor;
import comhms.src.hms.staff.model.Nurse;
import comhms.src.hms.admin.model.Schedule;
import comhms.src.hms.auth.controller.UserLoginService;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class StaffService {
    private List<Schedule> scheduleDatabase; // Simulated Schedule table
    private UserLoginService loginService; // For authentication and user data

    // Constructor
    public StaffService(UserLoginService loginService) {
        this.scheduleDatabase = new ArrayList<>();
        this.loginService = loginService;
        initializeDefaultSchedules();
    }

    // Overloaded Constructor
    public StaffService(UserLoginService loginService, List<Schedule> initialSchedules) {
        this.scheduleDatabase = initialSchedules != null ? initialSchedules : new ArrayList<>();
        this.loginService = loginService;
    }

    // Inner Class for Service Operation Result
    private class OperationResult {
        private boolean success;
        private String message;

        OperationResult(boolean success, String message) {
            this.success = success;
            this.message = message;
        }

        String getMessage() {
            return message;
        }
    }

    // Method with Object Reference
    public OperationResult performClinicalTask(Staff staff, String patientID, String taskDetails) 
            throws Staff.StaffAccessException {
        if (!(staff instanceof ClinicalStaff)) {
            throw new Staff.StaffAccessException("Only clinical staff can perform clinical tasks.");
        }
        String result = ((ClinicalStaff) staff).performClinicalTask(patientID, taskDetails);
        return new OperationResult(true, result);
    }

    // Method without Object Reference (Static)
    public static String getServiceDescription() {
        return "StaffService: Manages staff tasks like schedules, clinical tasks, and reports.";
    }

    // Overloaded Method: Generate Report (Doctor)
    public String generateReport(Doctor doctor, String patientID) throws Staff.StaffAccessException {
        return doctor.generateConsultationReport(scheduleDatabase, patientID);
    }

    // Overloaded Method: Generate Report (Nurse)
    public String generateReport(Nurse nurse, String shiftDate) throws Staff.StaffAccessException {
        return nurse.generateShiftReport(scheduleDatabase, shiftDate);
    }

    // Method to Get Schedules
    public List<Schedule> getSchedules() {
        return new ArrayList<>(scheduleDatabase);
    }

    // Method to Update Profile (Specialization)
    public String updateProfile(Staff staff, String newSpecialization) throws Staff.StaffAccessException {
        return staff.updateProfile(newSpecialization);
    }

    // Method to Update Profile (Specialization and Department)
    public String updateProfile(Staff staff, String newSpecialization, String newDepartment) 
            throws Staff.StaffAccessException {
        return staff.updateProfile(newSpecialization, newDepartment);
    }

    // Method to Update Credentials (Clinical Staff)
    public String updateCredentials(ClinicalStaff staff, String newLicenseNumber) 
            throws Staff.StaffAccessException {
        return staff.updateCredentials(newLicenseNumber);
    }

    // Method to Update Consultation Fee (Doctor)
    public String updateConsultationFee(Doctor doctor, double newFee, String reason) 
            throws Staff.StaffAccessException {
        return reason == null || reason.isEmpty() ? doctor.updateConsultationFee(newFee) : 
                                                   doctor.updateConsultationFee(newFee, reason);
    }

    // Method to Update Shift Type (Nurse)
    public String updateShiftType(Nurse nurse, String newShiftType, String reason) 
            throws Staff.StaffAccessException {
        return reason == null || reason.isEmpty() ? nurse.updateShiftType(newShiftType) : 
                                                   nurse.updateShiftType(newShiftType, reason);
    }

    // User Defined Exception
    public static class StaffServiceException extends Exception {
        public StaffServiceException(String message) {
            super(message);
        }
    }

    // Private Helper Method
    private void initializeDefaultSchedules() {
        try {
            scheduleDatabase.add(new Schedule(1, 2, "2025-05-04 09:00", "2025-05-04 10:00", "Booked", "Room 101"));
            scheduleDatabase.add(new Schedule(2, 3, "2025-05-04 08:00", "2025-05-04 16:00", "Booked", "Ward A"));
        } catch (Schedule.InvalidScheduleException e) {
            // Ignore for now
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StaffService)) return false;
        StaffService that = (StaffService) o;
        return Objects.equals(scheduleDatabase, that.scheduleDatabase);
    }

    @Override
    public int hashCode() {
        return Objects.hash(scheduleDatabase);
    }
}