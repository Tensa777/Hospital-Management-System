package comhms.src.hms.patient.controller;

import comhms.src.hms.patient.model.Patient;
import comhms.src.hms.patient.model.MedicalRecord;
import comhms.src.hms.reception.model.Appointment;
import comhms.src.hms.admin.model.Schedule;
import comhms.src.hms.auth.controller.UserLoginService;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class PatientService {
    private List<Appointment> appointmentDatabase; // Simulated Appointment table
    private List<Schedule> scheduleDatabase; // Simulated Schedule table
    private List<MedicalRecord> medicalRecordDatabase; // Simulated MedicalRecord table
    private UserLoginService loginService; // For authentication and user data

    // Constructor
    public PatientService(UserLoginService loginService) {
        this.appointmentDatabase = new ArrayList<>();
        this.scheduleDatabase = new ArrayList<>();
        this.medicalRecordDatabase = new ArrayList<>();
        this.loginService = loginService;
        initializeDefaultData();
    }

    // Overloaded Constructor
    public PatientService(UserLoginService loginService, List<Appointment> initialAppointments, 
                         List<Schedule> initialSchedules, List<MedicalRecord> initialMedicalRecords) {
        this.appointmentDatabase = initialAppointments != null ? initialAppointments : new ArrayList<>();
        this.scheduleDatabase = initialSchedules != null ? initialSchedules : new ArrayList<>();
        this.medicalRecordDatabase = initialMedicalRecords != null ? initialMedicalRecords : new ArrayList<>();
        this.loginService = loginService;
    }

    // Inner Class for Service Operation Result
    private class OperationResult {
        private boolean success;
        private String message;

        OperationResult(boolean success, String message) {
            this.success = success;
            this.message = message;
        }

        String getMessage() {
            return message;
        }
    }

    // Method with Object Reference
    public String viewAppointments(Patient patient) throws Patient.PatientAccessException {
        OperationResult opResult = new OperationResult(true, 
            patient.viewAppointments(appointmentDatabase));
        return opResult.getMessage();
    }

    // Method without Object Reference (Static)
    public static String getServiceDescription() {
        return "PatientService: Manages patient tasks like viewing appointments and medical records.";
    }

    // Overloaded Method: View Medical Record (Basic)
    public String viewMedicalRecord(Patient patient) throws Patient.PatientAccessException {
        StringBuilder result = new StringBuilder("Medical Records for Patient " + patient.getPatientID() + ":\n");
        boolean hasRecords = false;
        for (MedicalRecord record : medicalRecordDatabase) {
            if (patient.getPatientID().equals(record.getPatientID())) {
                result.append(record.getRecordDetails()).append("\n");
                hasRecords = true;
            }
        }
        if (!hasRecords) {
            result.append("No medical records found.\n");
        }
        OperationResult opResult = new OperationResult(true, 
            result + patient.viewMedicalRecord());
        return opResult.getMessage();
    }

    // Overloaded Method: View Medical Record (With Appointment)
    public String viewMedicalRecord(Patient patient, int appointmentID) 
            throws Patient.PatientAccessException {
        Appointment appointment = findAppointmentByID(appointmentID);
        if (appointment == null || !patient.getPatientID().equals(appointment.getPatientID())) {
            throw new Patient.PatientAccessException("Invalid or mismatched appointment ID.");
        }
        StringBuilder result = new StringBuilder("Medical Records for Patient " + 
                                                patient.getPatientID() + 
                                                " (Appointment " + appointmentID + "):\n");
        boolean hasRecords = false;
        for (MedicalRecord record : medicalRecordDatabase) {
            if (patient.getPatientID().equals(record.getPatientID()) && 
                record.getAppointmentID() == appointmentID) {
                result.append(record.getRecordDetails()).append("\n");
                hasRecords = true;
            }
        }
        if (!hasRecords) {
            result.append("No medical records found for this appointment.\n");
        }
        OperationResult opResult = new OperationResult(true, 
            result + patient.viewMedicalRecord(appointment));
        return opResult.getMessage();
    }

    // Method to View Appointment Schedule
    public String viewAppointmentSchedule(Patient patient, int appointmentID) 
            throws Patient.PatientAccessException {
        Appointment appointment = findAppointmentByID(appointmentID);
        if (appointment == null || !patient.getPatientID().equals(appointment.getPatientID())) {
            throw new Patient.PatientAccessException("Invalid or mismatched appointment ID.");
        }
        OperationResult opResult = new OperationResult(true, 
            patient.viewAppointmentSchedule(appointment, scheduleDatabase));
        return opResult.getMessage();
    }

    // User Defined Exception
    public static class PatientServiceException extends Exception {
        public PatientServiceException(String message) {
            super(message);
        }
    }

    // Helper Method to Find Appointment by ID
    private Appointment findAppointmentByID(int appointmentID) {
        for (Appointment appointment : appointmentDatabase) {
            if (appointment.getAppointmentID() == appointmentID) {
                return appointment;
            }
        }
        return null;
    }

    // Private Helper Method to Initialize Default Data
    private void initializeDefaultData() {
        try {
            scheduleDatabase.add(new Schedule(1, 2, "2025-05-04 09:00", "2025-05-04 10:00", 
                                            "Available", "Room 101"));
            appointmentDatabase.add(new Appointment(1, "PAT001", 1, "Confirmed"));
            medicalRecordDatabase.add(new MedicalRecord(1, "PAT001", "Type 2 Diabetes", 
                                                      "Metformin 500mg daily", null, 1));
        } catch (Schedule.InvalidScheduleException e) {
            // Ignore for now
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PatientService)) return false;
        PatientService that = (PatientService) o;
        return Objects.equals(appointmentDatabase, that.appointmentDatabase) &&
               Objects.equals(scheduleDatabase, that.scheduleDatabase) &&
               Objects.equals(medicalRecordDatabase, that.medicalRecordDatabase);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appointmentDatabase, scheduleDatabase, medicalRecordDatabase);
    }
}