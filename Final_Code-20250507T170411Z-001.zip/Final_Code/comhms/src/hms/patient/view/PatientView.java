package comhms.src.hms.patient.view;

import comhms.src.hms.patient.model.Patient;
import comhms.src.hms.admin.model.Schedule.InvalidScheduleException;
import comhms.src.hms.auth.controller.UserLoginService;
import java.util.Scanner;

public class PatientView {
    private Scanner scanner;
    private Patient patient;
    private UserLoginService loginService; // For authentication
    private PatientService patientService; // For backend logic

    // Constructor
    public PatientView(Patient patient, UserLoginService loginService) {
        this.scanner = new Scanner(System.in);
        this.patient = patient;
        this.loginService = loginService;
        this.patientService = new PatientService(loginService); // Placeholder
    }

    // Overloaded Constructor
    public PatientView(Patient patient, UserLoginService loginService, PatientService patientService) {
        this.scanner = new Scanner(System.in);
        this.patient = patient;
        this.loginService = loginService;
        this.patientService = patientService;
    }

    // Inner Class for Menu Options
    private class MenuOption {
        private String description;
        private Runnable action;

        MenuOption(String description, Runnable action) {
            this.description = description;
            this.action = action;
        }

        void display(int index) {
            System.out.println(index + ". " + description);
        }

        void execute() {
            action.run();
        }
    }

    // Method with Object Reference
    public void displayPatientMenu(Patient patient) {
        this.patient = patient; // Update patient reference
        MenuOption[] options = {
            new MenuOption("View Appointments", this::handleViewAppointments),
            new MenuOption("View Medical Record", this::handleViewMedicalRecord),
            new MenuOption("View Appointment Schedule", this::handleViewAppointmentSchedule),
            new MenuOption("Update Profile", this::handleUpdateProfile),
            new MenuOption("Logout", () -> System.out.println("Logging out..."))
        };

        while (true) {
            System.out.println("\n=== Patient Dashboard ===");
            System.out.println("Welcome, " + patient.getUsername() + " (Patient)");
            for (int i = 0; i < options.length; i++) {
                options[i].display(i + 1);
            }

            int choice = getValidChoice(options.length);
            if (choice == options.length) { // Logout
                options[choice - 1].execute();
                break;
            }
            options[choice - 1].execute();
        }
    }

    // Method without Object Reference (Static)
    public static String getWelcomeMessage() {
        return "Welcome to the Patient Dashboard!";
    }

    // Handle View Appointments
    private void handleViewAppointments() {
        try {
            String appointments = patientService.viewAppointments(patient);
            System.out.println(appointments);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Handle View Medical Record
    private void handleViewMedicalRecord() {
        try {
            System.out.println("1. View General Medical Record");
            System.out.println("2. View Medical Record for Appointment");
            System.out.println("3. Back");
            int choice = getValidChoice(3);
            if (choice == 3) return;

            if (choice == 1) {
                String record = patientService.viewMedicalRecord(patient);
                System.out.println(record);
            } else {
                System.out.print("Enter Appointment ID (e.g., 1): ");
                int appointmentID = Integer.parseInt(scanner.nextLine());
                String record = patientService.viewMedicalRecord(patient, appointmentID);
                System.out.println(record);
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: Please enter a valid number for Appointment ID.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Handle View Appointment Schedule
    private void handleViewAppointmentSchedule() {
        try {
            System.out.print("Enter Appointment ID (e.g., 1): ");
            int appointmentID = Integer.parseInt(scanner.nextLine());
            String schedule = patientService.viewAppointmentSchedule(patient, appointmentID);
            System.out.println(schedule);
        } catch (NumberFormatException e) {
            System.out.println("Error: Please enter a valid number for Appointment ID.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Handle Update Profile
    private void handleUpdateProfile() {
        System.out.println("\n=== Update Profile ===");
        System.out.println("1. Update Medical History");
        System.out.println("2. Back");
        int choice = getValidChoice(2);
        if (choice == 2) return;

        try {
            if (choice == 1) {
                System.out.print("Enter New Medical History (e.g., Diabetes, Hypertension): ");
                String newMedicalHistory = scanner.nextLine();
                patient.setMedicalHistory(newMedicalHistory);
                System.out.println("Medical history updated to: " + newMedicalHistory);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Helper Method
    private int getValidChoice(int max) {
        while (true) {
            try {
                System.out.print("Enter choice (1-" + max + "): ");
                int choice = Integer.parseInt(scanner.nextLine());
                if (choice >= 1 && choice <= max) {
                    return choice;
                }
                System.out.println("Invalid choice! Try again.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number!");
            }
        }
    }
}

// Placeholder PatientService
class PatientService {
    private comhms.src.hms.auth.controller.UserLoginService loginService;

    public PatientService(comhms.src.hms.auth.controller.UserLoginService loginService) {
        this.loginService = loginService;
    }

    public String viewAppointments(Patient patient) 
            throws comhms.src.hms.patient.model.Patient.PatientAccessException {
        comhms.src.hms.reception.model.Appointment appointment = new comhms.src.hms.reception.model.Appointment(
            1, patient.getPatientID(), 1, "Confirmed");
        return patient.viewAppointments(java.util.Arrays.asList(appointment));
    }

    public String viewMedicalRecord(Patient patient) 
            throws comhms.src.hms.patient.model.Patient.PatientAccessException {
        return patient.viewMedicalRecord();
    }

    public String viewMedicalRecord(Patient patient, int appointmentID) 
            throws comhms.src.hms.patient.model.Patient.PatientAccessException {
        comhms.src.hms.reception.model.Appointment appointment = new comhms.src.hms.reception.model.Appointment(
            appointmentID, patient.getPatientID(), 1, "Confirmed");
        return patient.viewMedicalRecord(appointment);
    }

    public String viewAppointmentSchedule(Patient patient, int appointmentID) 
            throws comhms.src.hms.patient.model.Patient.PatientAccessException, InvalidScheduleException {
        comhms.src.hms.reception.model.Appointment appointment = new comhms.src.hms.reception.model.Appointment(
            appointmentID, patient.getPatientID(), 1, "Confirmed");
        comhms.src.hms.admin.model.Schedule schedule = new comhms.src.hms.admin.model.Schedule(
            1, 2, "2025-05-04 09:00", "2025-05-04 10:00", "Booked", "Room 101");
        return patient.viewAppointmentSchedule(appointment, java.util.Arrays.asList(schedule));
    }
}