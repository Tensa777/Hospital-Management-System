package comhms.src.hms.patient.util;

import comhms.src.hms.patient.model.MedicalRecord;
import comhms.src.hms.patient.model.Patient;
import java.text.SimpleDateFormat;
import java.util.List;

public class MedicalRecordFormatter {
    private String dateFormat; // Configurable date format

    // Constructor
    public MedicalRecordFormatter() {
        this.dateFormat = "yyyy-MM-dd HH:mm:ss"; // Default format
    }

    // Overloaded Constructor
    public MedicalRecordFormatter(String dateFormat) {
        this.dateFormat = dateFormat != null && !dateFormat.trim().isEmpty() ? 
                         dateFormat : "yyyy-MM-dd HH:mm:ss";
    }

    // Inner Class for Format Configuration
    private class FormatConfig {
        private boolean includeDetails;
        private boolean patientFriendly;

        FormatConfig(boolean includeDetails, boolean patientFriendly) {
            this.includeDetails = includeDetails;
            this.patientFriendly = patientFriendly;
        }

        String getFormatDescription() {
            return (patientFriendly ? "Patient-Friendly" : "Standard") + 
                   (includeDetails ? ", Detailed" : ", Summary");
        }
    }

    // Method with Object Reference
    public String formatRecord(MedicalRecord record, Patient patient) 
            throws MedicalRecordFormatterException {
        if (record == null || patient == null) {
            throw new MedicalRecordFormatterException("Medical record or patient cannot be null.");
        }
        if (!patient.getPatientID().equals(record.getPatientID())) {
            throw new MedicalRecordFormatterException("Medical record does not belong to patient.");
        }
        FormatConfig config = new FormatConfig(true, false); // Detailed, standard
        return formatRecordInternal(record, config);
    }

    // Method without Object Reference (Static)
    public static String getFormatterDescription() {
        return "MedicalRecordFormatter: Formats medical records for display.";
    }

    // Overloaded Method: Format Single Record (Summary)
    public String formatRecordSummary(MedicalRecord record) throws MedicalRecordFormatterException {
        if (record == null) {
            throw new MedicalRecordFormatterException("Medical record cannot be null.");
        }
        FormatConfig config = new FormatConfig(false, false); // Summary, standard
        return formatRecordInternal(record, config);
    }

    // Overloaded Method: Format Multiple Records (Patient-Friendly)
    public String formatPatientFriendlyRecords(List<MedicalRecord> records, Patient patient) 
            throws MedicalRecordFormatterException {
        if (records == null || patient == null) {
            throw new MedicalRecordFormatterException("Records or patient cannot be null.");
        }
        StringBuilder result = new StringBuilder("Medical Records for " + patient.getUsername() + ":\n");
        FormatConfig config = new FormatConfig(true, true); // Detailed, patient-friendly
        boolean hasRecords = false;
        for (MedicalRecord record : records) {
            if (patient.getPatientID().equals(record.getPatientID())) {
                result.append(formatRecordInternal(record, config)).append("\n");
                hasRecords = true;
            }
        }
        if (!hasRecords) {
            result.append("No medical records found.");
        }
        return result.toString();
    }

    // Private Helper Method to Format Record
    private String formatRecordInternal(MedicalRecord record, FormatConfig config) {
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        StringBuilder formatted = new StringBuilder();
        if (config.patientFriendly) {
            formatted.append("Record ID: ").append(record.getRecordID()).append("\n");
            formatted.append("Date: ").append(sdf.format(record.getRecordDate())).append("\n");
            formatted.append("Condition: ").append(record.getDiagnosis()).append("\n");
            formatted.append("Treatment Plan: ").append(record.getTreatment()).append("\n");
            if (record.getAppointmentID() != 0) {
                formatted.append("Related Appointment: ").append(record.getAppointmentID()).append("\n");
            }
        } else if (config.includeDetails) {
            formatted.append("Medical Record [ID=").append(record.getRecordID())
                     .append(", PatientID=").append(record.getPatientID())
                     .append(", Diagnosis=").append(record.getDiagnosis())
                     .append(", Treatment=").append(record.getTreatment())
                     .append(", Date=").append(sdf.format(record.getRecordDate()))
                     .append(", AppointmentID=").append(record.getAppointmentID() == 0 ? 
                                                       "None" : record.getAppointmentID())
                     .append("]");
        } else {
            formatted.append("Record ID=").append(record.getRecordID())
                     .append(", Diagnosis=").append(record.getDiagnosis())
                     .append(", Date=").append(sdf.format(record.getRecordDate()));
        }
        return formatted.toString() + " [" + config.getFormatDescription() + "]";
    }

    // User Defined Exception
    public static class MedicalRecordFormatterException extends Exception {
        public MedicalRecordFormatterException(String message) {
            super(message);
        }
    }

    // Getter and Setter for Testing
    public String getDateFormat() { return dateFormat; }
    public void setDateFormat(String dateFormat) { 
        this.dateFormat = dateFormat != null && !dateFormat.trim().isEmpty() ? 
                         dateFormat : "yyyy-MM-dd HH:mm:ss"; 
    }
}