package comhms.src.hms.patient.model;

import comhms.src.hms.auth.model.UserLogin;
import comhms.src.hms.reception.model.Appointment;
import comhms.src.hms.admin.model.Schedule;
import java.util.List;

public class Patient extends UserLogin {
    private String patientID; // E.g., PAT001
    private String medicalHistory; // Simplified as a string (e.g., "Diabetes, Hypertension")

    // Constructor
    public Patient(int userID, String username, String password, String name, int age, 
                   String patientID, String medicalHistory) {
        super(userID, username, password, "Patient", "Patient", name, age, medicalHistory, medicalHistory);
        this.patientID = patientID;
        this.medicalHistory = medicalHistory != null ? medicalHistory : "No medical history provided";
    }

    // Overloaded Constructor
    public Patient(int userID, String username, String password, String name, int age, 
                   String patientID, String medicalHistory, String securityQuestion, 
                   String securityAnswer) {
        super(userID, username, password, "Patient", "Patient", name, age, 
              securityQuestion, securityAnswer);
        this.patientID = patientID;
        this.medicalHistory = medicalHistory != null ? medicalHistory : "No medical history provided";
    }

    // Inner Class for Patient Task
    private class PatientTask {
        private String taskType;
        private String details;

        PatientTask(String taskType, String details) {
            this.taskType = taskType;
            this.details = details;
        }

        String getTaskSummary() {
            return "Task: " + taskType + ", Details: " + details;
        }
    }

    // Method with Object Reference
    public String viewAppointments(List<Appointment> appointments) throws PatientAccessException {
        if (appointments == null) {
            throw new PatientAccessException("Appointment list cannot be null.");
        }
        StringBuilder result = new StringBuilder("Appointments for Patient " + patientID + ":\n");
        boolean hasAppointments = false;
        for (Appointment appointment : appointments) {
            if (patientID.equals(appointment.getPatientID()) && 
                !"Canceled".equals(appointment.getStatus())) {
                result.append(appointment.toString()).append("\n");
                hasAppointments = true;
            }
        }
        if (!hasAppointments) {
            result.append("No active appointments found.");
        }
        PatientTask task = new PatientTask("View Appointments", "Retrieved for " + patientID);
        return result.toString() + "\n" + task.getTaskSummary();
    }

    // Method without Object Reference (Static)
    public static String getPatientRoleDescription() {
        return "Patient: Views appointments and medical records.";
    }

    // Overloaded Method: View Medical Record (Basic)
    public String viewMedicalRecord() throws PatientAccessException {
        if (medicalHistory == null || medicalHistory.trim().isEmpty()) {
            throw new PatientAccessException("No medical history available.");
        }
        PatientTask task = new PatientTask("View Medical Record", "Retrieved for " + patientID);
        return "Medical History for " + patientID + ": " + medicalHistory + "\n" + task.getTaskSummary();
    }

    // Overloaded Method: View Medical Record (With Appointment Context)
    public String viewMedicalRecord(Appointment appointment) throws PatientAccessException {
        if (appointment == null || !patientID.equals(appointment.getPatientID())) {
            throw new PatientAccessException("Invalid or mismatched appointment for patient.");
        }
        if (medicalHistory == null || medicalHistory.trim().isEmpty()) {
            throw new PatientAccessException("No medical history available.");
        }
        PatientTask task = new PatientTask("View Medical Record", 
                                         "Retrieved for " + patientID + " with Appointment " + 
                                         appointment.getAppointmentID());
        return "Medical History for " + patientID + " (Appointment " + 
               appointment.getAppointmentID() + "): " + medicalHistory + "\n" + task.getTaskSummary();
    }

    // Method to View Schedule Details for an Appointment
    public String viewAppointmentSchedule(Appointment appointment, List<Schedule> schedules) 
            throws PatientAccessException {
        if (appointment == null || schedules == null) {
            throw new PatientAccessException("Appointment or schedule list cannot be null.");
        }
        if (!patientID.equals(appointment.getPatientID())) {
            throw new PatientAccessException("Appointment does not belong to this patient.");
        }
        for (Schedule schedule : schedules) {
            if (schedule.getScheduleID() == appointment.getScheduleID()) {
                PatientTask task = new PatientTask("View Appointment Schedule", 
                                                 "Retrieved for Appointment " + 
                                                 appointment.getAppointmentID());
                return "Schedule for Appointment " + appointment.getAppointmentID() + ":\n" + 
                       schedule.toString() + "\n" + task.getTaskSummary();
            }
        }
        throw new PatientAccessException("No matching schedule found for appointment.");
    }

    // User Defined Exception
    public static class PatientAccessException extends Exception {
        public PatientAccessException(String message) {
            super(message);
        }
    }

    // Getters and Setters
    public String getPatientID() { return patientID; }
    public String getMedicalHistory() { return medicalHistory; }
    public void setMedicalHistory(String medicalHistory) { 
        this.medicalHistory = medicalHistory != null ? medicalHistory : "No medical history provided"; 
    }

    // Override toString
    @Override
    public String toString() {
        PatientTask task = new PatientTask("N/A", "N/A");
        return "Patient [Username=" + getUsername() + ", PatientID=" + patientID + 
               ", MedicalHistory=" + medicalHistory + ", TaskSummary=" + task.getTaskSummary() + "]";
    }
}