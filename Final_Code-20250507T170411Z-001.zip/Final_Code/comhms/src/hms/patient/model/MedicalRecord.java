package comhms.src.hms.patient.model;

import comhms.src.hms.reception.model.Appointment;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class MedicalRecord {
    private int recordID; // E.g., 1
    private String patientID; // E.g., PAT001
    private String diagnosis; // E.g., "Type 2 Diabetes"
    private String treatment; // E.g., "Metformin 500mg daily"
    private Timestamp recordDate; // When the record was created/updated
    private int appointmentID; // Links to Appointment (optional)

    // Constructor
    public MedicalRecord(int recordID, String patientID, String diagnosis, String treatment) {
        this.recordID = recordID;
        this.patientID = patientID;
        this.diagnosis = diagnosis != null ? diagnosis : "No diagnosis provided";
        this.treatment = treatment != null ? treatment : "No treatment provided";
        this.recordDate = new Timestamp(System.currentTimeMillis());
        this.appointmentID = 0; // Default: no linked appointment
    }

    // Overloaded Constructor
    public MedicalRecord(int recordID, String patientID, String diagnosis, String treatment, 
                        Timestamp recordDate, int appointmentID) {
        this.recordID = recordID;
        this.patientID = patientID;
        this.diagnosis = diagnosis != null ? diagnosis : "No diagnosis provided";
        this.treatment = treatment != null ? treatment : "No treatment provided";
        this.recordDate = recordDate != null ? recordDate : new Timestamp(System.currentTimeMillis());
        this.appointmentID = appointmentID;
    }

    // Inner Class for Record Update
    private class RecordUpdate {
        private String updateType;
        private String details;

        RecordUpdate(String updateType, String details) {
            this.updateType = updateType;
            this.details = details;
        }

        String getUpdateSummary() {
            return "Update: " + updateType + ", Details: " + details;
        }
    }

    // Method with Object Reference
    public String updateDiagnosis(Appointment appointment, String newDiagnosis) 
            throws MedicalRecordException {
        if (appointment != null && appointment.getAppointmentID() != this.appointmentID) {
            throw new MedicalRecordException("Mismatched appointment ID for record update.");
        }
        if (newDiagnosis == null || newDiagnosis.trim().isEmpty()) {
            throw new MedicalRecordException("Diagnosis cannot be null or empty.");
        }
        this.diagnosis = newDiagnosis;
        this.recordDate = new Timestamp(System.currentTimeMillis());
        RecordUpdate update = new RecordUpdate("Diagnosis Update", "Updated to: " + newDiagnosis);
        return "Medical record " + recordID + " updated for patient " + patientID + ". " + 
               update.getUpdateSummary();
    }

    // Method without Object Reference (Static)
    public static String getMedicalRecordDescription() {
        return "MedicalRecord: Stores patient diagnosis and treatment details.";
    }

    // Overloaded Method: Update Treatment (Basic)
    public String updateTreatment(String newTreatment) throws MedicalRecordException {
        if (newTreatment == null || newTreatment.trim().isEmpty()) {
            throw new MedicalRecordException("Treatment cannot be null or empty.");
        }
        this.treatment = newTreatment;
        this.recordDate = new Timestamp(System.currentTimeMillis());
        RecordUpdate update = new RecordUpdate("Treatment Update", "Updated to: " + newTreatment);
        return "Medical record " + recordID + " updated for patient " + patientID + ". " + 
               update.getUpdateSummary();
    }

    // Overloaded Method: Update Treatment (With Appointment)
    public String updateTreatment(Appointment appointment, String newTreatment) 
            throws MedicalRecordException {
        if (appointment != null && appointment.getAppointmentID() != this.appointmentID) {
            throw new MedicalRecordException("Mismatched appointment ID for record update.");
        }
        if (newTreatment == null || newTreatment.trim().isEmpty()) {
            throw new MedicalRecordException("Treatment cannot be null or empty.");
        }
        this.treatment = newTreatment;
        this.recordDate = new Timestamp(System.currentTimeMillis());
        RecordUpdate update = new RecordUpdate("Treatment Update", 
                                             "Updated to: " + newTreatment + 
                                             " for Appointment " + appointmentID);
        return "Medical record " + recordID + " updated for patient " + patientID + ". " + 
               update.getUpdateSummary();
    }

    // Method to Get Record Details
    public String getRecordDetails() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        RecordUpdate update = new RecordUpdate("N/A", "N/A");
        return "Medical Record [ID=" + recordID + ", PatientID=" + patientID + 
               ", Diagnosis=" + diagnosis + ", Treatment=" + treatment + 
               ", RecordDate=" + sdf.format(recordDate) + 
               ", AppointmentID=" + (appointmentID == 0 ? "None" : appointmentID) + 
               ", UpdateSummary=" + update.getUpdateSummary() + "]";
    }

    // User Defined Exception
    public static class MedicalRecordException extends Exception {
        public MedicalRecordException(String message) {
            super(message);
        }
    }

    // Getters and Setters
    public int getRecordID() { return recordID; }
    public String getPatientID() { return patientID; }
    public String getDiagnosis() { return diagnosis; }
    public String getTreatment() { return treatment; }
    public Timestamp getRecordDate() { return recordDate; }
    public int getAppointmentID() { return appointmentID; }
    public void setDiagnosis(String diagnosis) { 
        this.diagnosis = diagnosis != null ? diagnosis : "No diagnosis provided"; 
    }
    public void setTreatment(String treatment) { 
        this.treatment = treatment != null ? treatment : "No treatment provided"; 
    }

    // Override toString
    @Override
    public String toString() {
        return getRecordDetails();
    }
}