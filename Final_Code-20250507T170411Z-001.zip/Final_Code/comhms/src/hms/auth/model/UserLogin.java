package comhms.src.hms.auth.model;

import java.sql.Timestamp;
import java.util.Objects;
import java.util.regex.Pattern;

public class UserLogin {
    private int userID;
    private String username;
    private String password; // Plain text
    protected String role;
    private String subRole; // For Staff (Doctor, Nurse)
    private String name;
    private int age;
    private String securityQuestion;
    private String securityAnswer;
    private Timestamp lastLogin;
    private int failedAttempts;
    private boolean accountLocked;

    // Constructor
    public UserLogin(int userID, String username, String password, String role, String name, int age) {
        this.userID = userID;
        this.username = username;
        this.password = password;
        this.role = role;
        this.name = name;
        this.age = age;
        this.failedAttempts = 0;
        this.accountLocked = false;
    }

    // Overloaded Constructor
    public UserLogin(int userID, String username, String password, String role, String subRole, String name, int age, String securityQuestion, String securityAnswer) {
        this(userID, username, password, role, name, age);
        this.subRole = subRole;
        this.securityQuestion = securityQuestion;
        this.securityAnswer = securityAnswer;
    }

    // Inner Class for Login Attempt
    private class LoginAttempt {
        private String ipAddress;
        private String deviceInfo;
        private boolean success;
        private Timestamp timestamp;

        LoginAttempt(String ipAddress, String deviceInfo, boolean success) {
            this.ipAddress = ipAddress;
            this.deviceInfo = deviceInfo;
            this.success = success;
            this.timestamp = new Timestamp(System.currentTimeMillis());
        }
    }

    // Method with Object Reference
    public boolean validateCredentials(UserLogin inputUser) throws InvalidCredentialsException {
        if (accountLocked) {
            throw new InvalidCredentialsException("Account is locked due to multiple failed attempts.");
        }
        if (inputUser.getUsername().equals(this.username) && inputUser.getPassword().equals(this.password)) {
            resetFailedAttempts();
            this.lastLogin = new Timestamp(System.currentTimeMillis());
            return true;
        }
        incrementFailedAttempts();
        throw new InvalidCredentialsException("Invalid username or password.");
    }

    // Method without Object Reference (Static)
    public static boolean isValidPassword(String password) {
        // 8-12 chars, at least one letter, number, special char
        String regex = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,12}$";
        return Pattern.matches(regex, password);
    }

    // User Defined Exception
    public static class InvalidCredentialsException extends Exception {
        public InvalidCredentialsException(String message) {
            super(message);
        }
    }

    // Getters and Setters
    public int getUserID() { return userID; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getRole() { return role; }
    public String getSubRole() { return subRole; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getSecurityQuestion() { return securityQuestion; }
    public String getSecurityAnswer() { return securityAnswer; }
    public Timestamp getLastLogin() { return lastLogin; }
    public int getFailedAttempts() { return failedAttempts; }
    public boolean isAccountLocked() { return accountLocked; }

    public void setSecurityQuestion(String question) { this.securityQuestion = question; }
    public void setSecurityAnswer(String answer) { this.securityAnswer = answer; }
    public void lockAccount() { this.accountLocked = true; }
    public void unlockAccount() { this.accountLocked = false; }

    private void incrementFailedAttempts() {
        failedAttempts++;
        if (failedAttempts >= 3) {
            lockAccount();
        }
    }

    private void resetFailedAttempts() {
        failedAttempts = 0;
        unlockAccount();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UserLogin)) return false;
        UserLogin user = (UserLogin) o;
        return userID == user.userID && username.equals(user.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userID, username);
    }
}