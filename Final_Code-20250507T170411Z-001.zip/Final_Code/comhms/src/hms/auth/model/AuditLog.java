package comhms.src.hms.auth.model;

import java.sql.Timestamp;
import java.util.Objects;

public class AuditLog {
    private int logID;
    private Integer userID; // Nullable for guest actions
    private String role;
    private String action;
    private ActionDetails details;
    private Timestamp timestamp;

    // Constructor
    public AuditLog(int logID, Integer userID, String role, String action, String ipAddress, String deviceInfo, boolean success) {
        this.logID = logID;
        this.userID = userID;
        this.role = role;
        this.action = action;
        this.details = new ActionDetails(ipAddress, deviceInfo, success);
        this.timestamp = new Timestamp(System.currentTimeMillis());
    }

    // Overloaded Constructor
    public AuditLog(int logID, Integer userID, String role, String action) {
        this(logID, userID, role, action, "192.168.1.1", "Unknown Device", false); // Default values
    }

    // Inner Class for Action Details
    private class ActionDetails {
        private String ipAddress;
        private String deviceInfo;
        private boolean success;

        ActionDetails(String ipAddress, String deviceInfo, boolean success) {
            this.ipAddress = ipAddress;
            this.deviceInfo = deviceInfo;
            this.success = success;
        }

        String getSummary() {
            return "IP: " + ipAddress + ", Device: " + deviceInfo + ", Success: " + success;
        }
    }

    // Method with Object Reference
    public boolean matchesUser(AuditLog otherLog) throws InvalidAuditLogException {
        if (otherLog == null) {
            throw new InvalidAuditLogException("Comparison log cannot be null.");
        }
        return this.userID != null && otherLog.userID != null && this.userID.equals(otherLog.userID);
    }

    // Method without Object Reference (Static)
    public static String formatAction(String action) {
        return action.toUpperCase().replace(" ", "_"); // E.g., "Login Attempt" -> "LOGIN_ATTEMPT"
    }

    // User Defined Exception
    public static class InvalidAuditLogException extends Exception {
        public InvalidAuditLogException(String message) {
            super(message);
        }
    }

    // Getters
    public int getLogID() { return logID; }
    public Integer getUserID() { return userID; }
    public String getRole() { return role; }
    public String getAction() { return action; }
    public String getDetailsSummary() { return details.getSummary(); }
    public Timestamp getTimestamp() { return timestamp; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AuditLog)) return false;
        AuditLog auditLog = (AuditLog) o;
        return logID == auditLog.logID;
    }

    @Override
    public int hashCode() {
        return Objects.hash(logID);
    }

    @Override
    public String toString() {
        return "AuditLog [ID=" + logID + ", UserID=" + (userID != null ? userID : "Guest") + 
               ", Role=" + role + ", Action=" + action + ", Details=" + getDetailsSummary() + 
               ", Timestamp=" + timestamp + "]";
    }
}