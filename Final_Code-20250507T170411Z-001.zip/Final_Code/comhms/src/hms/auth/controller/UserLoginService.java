package comhms.src.hms.auth.controller;

import comhms.src.hms.auth.model.UserLogin;
import comhms.src.hms.auth.model.AuditLog;
import comhms.src.hms.auth.util.DashboardRouter;
import comhms.src.hms.auth.util.DashboardRouter.InvalidRoleException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserLoginService {
    private List<UserLogin> userDatabase; // Simulated UserLogin table
    private List<AuditLog> auditLogDatabase; // Simulated Audit_Log table
    private Map<String, Integer> idCounters; // Track ID counts per role
    private DashboardRouter router; // To be implemented

    // Constructor
    public UserLoginService() {
        this.userDatabase = new ArrayList<>();
        this.auditLogDatabase = new ArrayList<>();
        this.idCounters = new HashMap<>();
        this.router = new DashboardRouter(); // Placeholder
        initializeDefaultUsers();
    }

    // Overloaded Constructor
    public UserLoginService(DashboardRouter router) {
        this.userDatabase = new ArrayList<>();
        this.auditLogDatabase = new ArrayList<>();
        this.idCounters = new HashMap<>();
        this.router = router;
        initializeDefaultUsers();
    }

    // Inner Class for Authentication Result
    private class AuthResult {
        private boolean success;
        private String message;

        AuthResult(boolean success, String message) {
            this.success = success;
            this.message = message;
        }
    }

    // Method with Object Reference
    public void login(UserLogin inputUser) throws UserLogin.InvalidCredentialsException {
        AuthResult result = authenticate(inputUser);
        logAuditAttempt(inputUser, result.success, result.message);
        if (!result.success) {
            throw new UserLogin.InvalidCredentialsException(result.message);
        }
    }

    // Method without Object Reference (Static)
    public static String generateIDPrefix(String role) {
        return role.substring(0, 2).toUpperCase(); // E.g., "Admin" -> "AD"
    }

    // Overloaded Method: Register User
    public void registerUser(UserLogin user) throws DuplicateUserException {
        if (isUsernameTaken(user.getUsername())) {
            throw new DuplicateUserException("Username already exists!");
        }
        userDatabase.add(user);
        logAuditAttempt(user, true, "User registered successfully");
        idCounters.put(user.getRole(), idCounters.getOrDefault(user.getRole(), 0) + 1);
    }

    // Overloaded Method: Register User with Custom ID
    public void registerUser(UserLogin user, String customID) throws DuplicateUserException {
        if (isUsernameTaken(user.getUsername())) {
            throw new DuplicateUserException("Username already exists!");
        }
        userDatabase.add(user);
        logAuditAttempt(user, true, "User registered with ID: " + customID);
    }

    // Method to Generate User ID
    public String generateUserID(String role) {
        String prefix = generateIDPrefix(role);
        int count = idCounters.getOrDefault(role, 0) + 1;
        return prefix + String.format("%04d", count); // E.g., AD0001
    }

    // Method to Get User by ID
    public UserLogin getUserByID(String userID) throws InvalidUserIDException {
        try {
            int id = Integer.parseInt(userID.substring(2));
            for (UserLogin user : userDatabase) {
                if (user.getUserID() == id && userID.startsWith(generateIDPrefix(user.getRole()))) {
                    return user;
                }
            }
        } catch (NumberFormatException e) {
            throw new InvalidUserIDException("Invalid User ID format!");
        }
        throw new InvalidUserIDException("User ID not found!");
    }

    // Method to Verify Security Answer
    public boolean verifySecurityAnswer(UserLogin user, String answer) {
        boolean success = user.getSecurityAnswer().equalsIgnoreCase(answer);
        logAuditAttempt(user, success, success ? "Security answer verified" : "Incorrect security answer");
        return success;
    }

    // Method to Route to Dashboard
    public void routeToDashboard(UserLogin user) throws InvalidRoleException {
        router.redirect(user); // Delegates to DashboardRouter
    }

    // User Defined Exception
    public static class DuplicateUserException extends Exception {
        public DuplicateUserException(String message) {
            super(message);
        }
    }

    // User Defined Exception
    public static class InvalidUserIDException extends Exception {
        public InvalidUserIDException(String message) {
            super(message);
        }
    }

    // Private Helper Methods
    private void initializeDefaultUsers() {
        // Add a default admin for testing
        try {
            UserLogin admin = new UserLogin(1, "admin1", "Pass@123", "Admin", "Nurse", "John Doe", 30, 
                                           "What is your pet's name?", "Max");
            userDatabase.add(admin);
            idCounters.put("Admin", 1);
        } catch (Exception e) {
            // Ignore for now
        }
    }

    private boolean isUsernameTaken(String username) {
        return userDatabase.stream().anyMatch(u -> u.getUsername().equals(username));
    }

    private AuthResult authenticate(UserLogin inputUser) {
        for (UserLogin user : userDatabase) {
            try {
                if (user.validateCredentials(inputUser)) {
                    return new AuthResult(true, "Login successful");
                }
            } catch (UserLogin.InvalidCredentialsException e) {
                return new AuthResult(false, e.getMessage());
            }
        }
        return new AuthResult(false, "Invalid username or password");
    }

    private void logAuditAttempt(UserLogin user, boolean success, String message) {
        int logID = auditLogDatabase.size() + 1;
        String role = user.getRole() + (user.getSubRole() != null ? "/" + user.getSubRole() : "");
        AuditLog log = new AuditLog(logID, user.getUserID(), role, "Login Attempt", 
                                    "192.168.1.1", "Desktop", success);
        auditLogDatabase.add(log);
        System.out.println("Audit Log: " + log); // For testing
    }

    // Getter for Audit Logs (for Admin)
    public List<AuditLog> getAuditLogs() {
        return new ArrayList<>(auditLogDatabase);
    }
}