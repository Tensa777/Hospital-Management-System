package comhms.src.hms.auth.view;

import comhms.src.hms.auth.model.UserLogin;
import comhms.src.hms.auth.controller.UserLoginService;
import comhms.src.hms.auth.util.CaptchaValidator;
import comhms.src.hms.auth.util.CaptchaValidator.InvalidCaptchaException;
import comhms.src.hms.auth.util.DashboardRouter.InvalidRoleException;

import java.util.Scanner;
import java.util.regex.Pattern;

public class LoginView {
    private Scanner scanner;
    private UserLoginService loginService; // To be implemented
    private CaptchaValidator captchaValidator; // To be implemented
    private int failedAttempts;

    // Constructor
    public LoginView() {
        this.scanner = new Scanner(System.in);
        this.loginService = new UserLoginService(); // Placeholder
        this.captchaValidator = new CaptchaValidator(); // Placeholder
        this.failedAttempts = 0;
    }

    // Overloaded Constructor
    public LoginView(UserLoginService loginService, CaptchaValidator captchaValidator) {
        this.scanner = new Scanner(System.in);
        this.loginService = loginService;
        this.captchaValidator = captchaValidator;
        this.failedAttempts = 0;
    }

    // Inner Class for Menu Options
    private class MenuOption {
        private String description;
        private Runnable action;

        MenuOption(String description, Runnable action) {
            this.description = description;
            this.action = action;
        }

        void display(int index) {
            System.out.println(index + ". " + description);
        }

        void execute() {
            action.run();
        }
    }

    // Method with Object Reference
    public void displayLoginMenu(UserLoginService service) {
        this.loginService = service; // Update service reference
        MenuOption[] options = {
            new MenuOption("Login", () -> {
                try {
                    handleLogin();
                } catch (InvalidCaptchaException | InvalidRoleException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }),
            new MenuOption("Create Account", this::handleCreateAccount),
            new MenuOption("Forgot Password", () -> {
                try {
                    handleForgotPassword();
                } catch (InvalidCaptchaException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }),
            new MenuOption("Exit", () -> System.exit(0))
        };

        while (true) {
            System.out.println("\n=== Hospital Management System ===");
            System.out.println("Welcome! Please choose an option:");
            for (int i = 0; i < options.length; i++) {
                options[i].display(i + 1);
            }

            int choice = getValidChoice(options.length);
            options[choice - 1].execute();
        }
    }

    // Method without Object Reference (Static)
    public static String getRolePrompt() {
        return "Select Role:\n1. Admin\n2. Receptionist\n3. Staff\n4. Patient";
    }

    // Handle Login
    private void handleLogin() throws InvalidCaptchaException, InvalidRoleException {
        System.out.println("\n=== Login ===");
        System.out.println(getRolePrompt());
        String role = getRoleInput();
        String subRole = role.equals("Staff") ? getSubRoleInput() : null;

        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        if (failedAttempts >= 3) {
            if (!captchaValidator.validateCaptcha()) {
                System.out.println("Captcha validation failed!");
                return;
            }
        }

        try {
            UserLogin user = new UserLogin(0, username, password, role, subRole, "", 0, password, password); // Temporary user
            loginService.login(user);
            failedAttempts = 0;
            System.out.println("Welcome back, " + username + "!");
            loginService.routeToDashboard(user); // Simulated redirect
        } catch (UserLogin.InvalidCredentialsException e) {
            failedAttempts++;
            System.out.println("Error: " + e.getMessage());
            if (failedAttempts >= 3) {
                System.out.println("Too many failed attempts. Please complete the captcha.");
            }
        }
    }

    // Handle Account Creation
    private void handleCreateAccount() {
        System.out.println("\n=== Create Account ===");
        System.out.println(getRolePrompt());
        String role = getRoleInput();
        String subRole = role.equals("Staff") ? getSubRoleInput() : null;

        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Age: ");
        int age = getValidAge();

        String username;
        do {
            System.out.print("Enter Username: ");
            username = scanner.nextLine();
        } while (!isValidUsername(username));

        String password;
        do {
            System.out.print("Enter Password (8-12 chars, letter, number, special char): ");
            password = scanner.nextLine();
            if (!UserLogin.isValidPassword(password)) {
                System.out.println("Invalid password format!");
                continue;
            }
            System.out.print("Confirm Password: ");
            String confirmPassword = scanner.nextLine();
            if (!password.equals(confirmPassword)) {
                System.out.println("Passwords do not match! ❌");
            } else {
                System.out.println("Passwords match! ✔️");
                break;
            }
        } while (true);

        System.out.println("Select Security Question:");
        String[] questions = {"What is your pet's name?", "What was your first school?", "Custom"};
        for (int i = 0; i < questions.length; i++) {
            System.out.println((i + 1) + ". " + questions[i]);
        }
        int qChoice = getValidChoice(questions.length);
        String securityQuestion = qChoice == questions.length ? getCustomQuestion() : questions[qChoice - 1];
        System.out.print("Enter Security Answer: ");
        String securityAnswer = scanner.nextLine();

        try {
            String userID = loginService.generateUserID(role); // Simulated ID
            UserLogin user = new UserLogin(Integer.parseInt(userID.substring(2)), username, password, role, subRole, name, age, securityQuestion, securityAnswer);
            loginService.registerUser(user);
            System.out.println("✅ Account created! Your User ID is: " + userID);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Handle Forgot Password
    private void handleForgotPassword() throws InvalidCaptchaException {
        System.out.println("\n=== Forgot Password ===");
        System.out.print("Enter User ID: ");
        String userID = scanner.nextLine();

        if (!captchaValidator.validateCaptcha()) {
            System.out.println("Captcha validation failed!");
            return;
        }

        try {
            UserLogin user = loginService.getUserByID(userID);
            System.out.println("Security Question: " + user.getSecurityQuestion());
            System.out.print("Enter Answer: ");
            String answer = scanner.nextLine();

            if (loginService.verifySecurityAnswer(user, answer)) {
                System.out.println("Password sent to your registered email. (Dev mode: Your password is: " + user.getPassword() + ")");
            } else {
                System.out.println("Incorrect security answer!");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Helper Methods
    private String getRoleInput() {
        int choice = getValidChoice(4);
        switch (choice) {
            case 1: return "Admin";
            case 2: return "Receptionist";
            case 3: return "Staff";
            case 4: return "Patient";
            default: return "Patient"; // Fallback
        }
    }

    private String getSubRoleInput() {
        System.out.println("Select Sub-Role:\n1. Doctor\n2. Nurse");
        int choice = getValidChoice(2);
        return choice == 1 ? "Doctor" : "Nurse";
    }

    private int getValidChoice(int max) {
        int choice;
        while (true) {
            try {
                System.out.print("Enter choice (1-" + max + "): ");
                choice = Integer.parseInt(scanner.nextLine());
                if (choice >= 1 && choice <= max) {
                    return choice;
                }
                System.out.println("Invalid choice! Try again.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number!");
            }
        }
    }

    private int getValidAge() {
        while (true) {
            try {
                int age = Integer.parseInt(scanner.nextLine());
                if (age > 0 && age < 150) {
                    return age;
                }
                System.out.println("Invalid age! Enter a valid age.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number!");
            }
        }
    }

    private boolean isValidUsername(String username) {
        return Pattern.matches("^[A-Za-z0-9]{3,20}$", username);
    }

    private String getCustomQuestion() {
        System.out.print("Enter Custom Security Question: ");
        return scanner.nextLine();
    }
}