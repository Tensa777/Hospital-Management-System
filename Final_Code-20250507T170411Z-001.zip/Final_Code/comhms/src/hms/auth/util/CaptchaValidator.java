package comhms.src.hms.auth.util;

import java.util.Random;
import java.util.Scanner;

public class CaptchaValidator {
    private Random random;
    private Scanner scanner;
    private Captcha currentCaptcha;

    // Constructor
    public CaptchaValidator() {
        this.random = new Random();
        this.scanner = new Scanner(System.in);
    }

    // Overloaded Constructor
    public CaptchaValidator(Random random, Scanner scanner) {
        this.random = random;
        this.scanner = scanner;
    }

    // Inner Class for Captcha
    private class Captcha {
        private int number1;
        private int number2;
        private int answer;

        Captcha() {
            this.number1 = random.nextInt(10) + 1; // 1-10
            this.number2 = random.nextInt(10) + 1; // 1-10
            this.answer = number1 + number2;
        }

        String getQuestion() {
            return "What is " + number1 + " + " + number2 + "?";
        }

        boolean isCorrect(int userAnswer) {
            return userAnswer == answer;
        }
    }

    // Method with Object Reference
    public boolean validateCaptcha(CaptchaValidator otherValidator) throws InvalidCaptchaException {
        if (otherValidator == null) {
            throw new InvalidCaptchaException("Validator cannot be null.");
        }
        return validateCaptcha(); // Delegate to main validation
    }

    // Method without Object Reference (Static)
    public static String getCaptchaInstruction() {
        return "Please solve the math captcha to proceed.";
    }

    // Main Validation Method
    public boolean validateCaptcha() throws InvalidCaptchaException {
        currentCaptcha = new Captcha();
        System.out.println(getCaptchaInstruction());
        System.out.println(currentCaptcha.getQuestion());

        try {
            System.out.print("Enter answer: ");
            int userAnswer = Integer.parseInt(scanner.nextLine());
            if (currentCaptcha.isCorrect(userAnswer)) {
                return true;
            } else {
                throw new InvalidCaptchaException("Incorrect captcha answer!");
            }
        } catch (NumberFormatException e) {
            throw new InvalidCaptchaException("Please enter a valid number!");
        }
    }

    // User Defined Exception
    public static class InvalidCaptchaException extends Exception {
        public InvalidCaptchaException(String message) {
            super(message);
        }
    }
}