package comhms.src.hms.auth.util;

import comhms.src.hms.auth.model.UserLogin;
import java.util.HashMap;
import java.util.Map;

public class DashboardRouter {
    private Map<String, String> dashboardMap;

    // Constructor
    public DashboardRouter() {
        this.dashboardMap = new HashMap<>();
        initializeDashboardMap();
    }

    // Overloaded Constructor
    public DashboardRouter(Map<String, String> customDashboardMap) {
        this.dashboardMap = customDashboardMap != null ? customDashboardMap : new HashMap<>();
        if (customDashboardMap == null) {
            initializeDashboardMap();
        }
    }

    // Inner Class for Dashboard Info
    private class DashboardInfo {
        private String name;
        private String description;

        DashboardInfo(String name, String description) {
            this.name = name;
            this.description = description;
        }

        String getRedirectMessage() {
            return "Redirecting to " + name + ": " + description;
        }
    }

    // Method with Object Reference
    public void redirect(UserLogin user) throws InvalidRoleException {
        if (user == null) {
            throw new InvalidRoleException("User cannot be null.");
        }
        String roleKey = user.getRole() + (user.getSubRole() != null ? "/" + user.getSubRole() : "");
        String dashboard = dashboardMap.getOrDefault(roleKey, "Unknown Dashboard");
        DashboardInfo info = new DashboardInfo(dashboard, getDashboardDescription(roleKey));
        System.out.println(info.getRedirectMessage());
    }

    // Method without Object Reference (Static)
    public static String getDefaultDashboard(String role) {
        return role + "Dashboard"; // E.g., "Admin" -> "AdminDashboard"
    }

    // Overloaded Method: Redirect with Custom Message
    public void redirect(UserLogin user, String customMessage) throws InvalidRoleException {
        if (user == null) {
            throw new InvalidRoleException("User cannot be null.");
        }
        String roleKey = user.getRole() + (user.getSubRole() != null ? "/" + user.getSubRole() : "");
        String dashboard = dashboardMap.getOrDefault(roleKey, "Unknown Dashboard");
        System.out.println(customMessage + " -> " + dashboard);
    }

    // User Defined Exception
    public static class InvalidRoleException extends Exception {
        public InvalidRoleException(String message) {
            super(message);
        }
    }

    // Private Helper Method
    private void initializeDashboardMap() {
        dashboardMap.put("Admin", "AdminDashboard");
        dashboardMap.put("Receptionist", "ReceptionistDashboard");
        dashboardMap.put("Staff/Doctor", "StaffDashboard (Doctor)");
        dashboardMap.put("Staff/Nurse", "StaffDashboard (Nurse)");
        dashboardMap.put("Patient", "PatientDashboard");
    }

    private String getDashboardDescription(String roleKey) {
        switch (roleKey) {
            case "Admin":
                return "Manage users, schedules, and reports";
            case "Receptionist":
                return "Handle patient registration and appointments";
            case "Staff/Doctor":
                return "View appointments and write prescriptions";
            case "Staff/Nurse":
                return "Record patient vitals and assist doctors";
            case "Patient":
                return "View medical history and appointments";
            default:
                return "Unknown dashboard";
        }
    }
}