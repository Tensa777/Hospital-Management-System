package comhms.src.hms.reception.controller;

import comhms.src.hms.reception.model.Receptionist;
import comhms.src.hms.reception.model.Appointment;
import comhms.src.hms.admin.model.Schedule;
import comhms.src.hms.auth.controller.UserLoginService;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ReceptionService {
    private List<Appointment> appointmentDatabase; // Simulated Appointment table
    private List<Schedule> scheduleDatabase; // Simulated Schedule table
    private UserLoginService loginService; // For authentication and user data

    // Constructor
    public ReceptionService(UserLoginService loginService) {
        this.appointmentDatabase = new ArrayList<>();
        this.scheduleDatabase = new ArrayList<>();
        this.loginService = loginService;
        initializeDefaultData();
    }

    // Overloaded Constructor
    public ReceptionService(UserLoginService loginService, List<Appointment> initialAppointments, 
                           List<Schedule> initialSchedules) {
        this.appointmentDatabase = initialAppointments != null ? initialAppointments : new ArrayList<>();
        this.scheduleDatabase = initialSchedules != null ? initialSchedules : new ArrayList<>();
        this.loginService = loginService;
    }

    // Inner Class for Service Operation Result
    private class OperationResult {
        private boolean success;
        private String message;

        OperationResult(boolean success, String message) {
            this.success = success;
            this.message = message;
        }

        String getMessage() {
            return message;
        }
    }

    // Method with Object Reference
    public String bookAppointment(Receptionist receptionist, int appointmentID, String patientID, 
                                 int scheduleID) throws Receptionist.ReceptionistAccessException, 
                                                       Appointment.AppointmentException {
        Schedule schedule = findScheduleByID(scheduleID);
        if (schedule == null) {
            throw new Receptionist.ReceptionistAccessException("Schedule ID " + scheduleID + " not found.");
        }
        Appointment appointment = new Appointment(appointmentID, patientID, scheduleID, "Pending");
        appointmentDatabase.add(appointment);
        String result = appointment.confirmAppointment(schedule);
        OperationResult opResult = new OperationResult(true, result);
        return opResult.getMessage();
    }

    // Method without Object Reference (Static)
    public static String getServiceDescription() {
        return "ReceptionService: Manages receptionist tasks like appointments and patient registration.";
    }

    // Overloaded Method: Register Patient (Basic)
    public String registerPatient(Receptionist receptionist, String patientID, String patientName) 
            throws Receptionist.ReceptionistAccessException {
        String result = receptionist.registerPatient(patientID, patientName);
        OperationResult opResult = new OperationResult(true, result);
        return opResult.getMessage();
    }

    // Overloaded Method: Register Patient (With Contact)
    public String registerPatient(Receptionist receptionist, String patientID, String patientName, 
                                 String contactInfo) throws Receptionist.ReceptionistAccessException {
        String result = receptionist.registerPatient(patientID, patientName, contactInfo);
        OperationResult opResult = new OperationResult(true, result);
        return opResult.getMessage();
    }

    // Method to View Available Schedules
    public String viewAvailableSchedules(Receptionist receptionist) 
            throws Receptionist.ReceptionistAccessException {
        String result = receptionist.viewAvailableSchedules(scheduleDatabase);
        OperationResult opResult = new OperationResult(true, result);
        return opResult.getMessage();
    }

    // Overloaded Method: Cancel Appointment (Basic)
    public String cancelAppointment(Receptionist receptionist, int appointmentID) 
            throws Appointment.AppointmentException {
        Appointment appointment = findAppointmentByID(appointmentID);
        if (appointment == null) {
            throw new Appointment.AppointmentException("Appointment ID " + appointmentID + " not found.");
        }
        String result = appointment.cancelAppointment();
        OperationResult opResult = new OperationResult(true, result);
        return opResult.getMessage();
    }

    // Overloaded Method: Cancel Appointment (With Reason)
    public String cancelAppointment(Receptionist receptionist, int appointmentID, String reason) 
            throws Appointment.AppointmentException {
        Appointment appointment = findAppointmentByID(appointmentID);
        if (appointment == null) {
            throw new Appointment.AppointmentException("Appointment ID " + appointmentID + " not found.");
        }
        String result = appointment.cancelAppointment(reason);
        OperationResult opResult = new OperationResult(true, result);
        return opResult.getMessage();
    }

    // User Defined Exception
    public static class ReceptionServiceException extends Exception {
        public ReceptionServiceException(String message) {
            super(message);
        }
    }

    // Helper Method to Find Appointment by ID
    private Appointment findAppointmentByID(int appointmentID) {
        for (Appointment appointment : appointmentDatabase) {
            if (appointment.getAppointmentID() == appointmentID) {
                return appointment;
            }
        }
        return null;
    }

    // Helper Method to Find Schedule by ID
    private Schedule findScheduleByID(int scheduleID) {
        for (Schedule schedule : scheduleDatabase) {
            if (schedule.getScheduleID() == scheduleID) {
                return schedule;
            }
        }
        return null;
    }

    // Private Helper Method to Initialize Default Data
    private void initializeDefaultData() {
        try {
            scheduleDatabase.add(new Schedule(1, 2, "2025-05-04 09:00", "2025-05-04 10:00", 
                                            "Available", "Room 101"));
            scheduleDatabase.add(new Schedule(2, 3, "2025-05-04 08:00", "2025-05-04 16:00", 
                                            "Available", "Ward A"));
        } catch (Schedule.InvalidScheduleException e) {
            // Ignore for now
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ReceptionService)) return false;
        ReceptionService that = (ReceptionService) o;
        return Objects.equals(appointmentDatabase, that.appointmentDatabase) &&
               Objects.equals(scheduleDatabase, that.scheduleDatabase);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appointmentDatabase, scheduleDatabase);
    }
}