package comhms.src.hms.reception.model;

import comhms.src.hms.admin.model.Schedule;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class Appointment {
    private int appointmentID; // E.g., 1
    private String patientID; // E.g., PAT001
    private int scheduleID; // Links to Schedule
    private String status; // E.g., Confirmed, Canceled, Pending
    private Timestamp bookingTimestamp; // When the appointment was booked

    // Constructor
    public Appointment(int appointmentID, String patientID, int scheduleID, String status) {
        this.appointmentID = appointmentID;
        this.patientID = patientID;
        this.scheduleID = scheduleID;
        this.status = validateStatus(status);
        this.bookingTimestamp = new Timestamp(System.currentTimeMillis());
    }

    // Overloaded Constructor
    public Appointment(int appointmentID, String patientID, int scheduleID, String status, 
                       Timestamp bookingTimestamp) {
        this.appointmentID = appointmentID;
        this.patientID = patientID;
        this.scheduleID = scheduleID;
        this.status = validateStatus(status);
        this.bookingTimestamp = bookingTimestamp != null ? bookingTimestamp : 
                               new Timestamp(System.currentTimeMillis());
    }

    // Inner Class for Appointment Details
    private class AppointmentDetails {
        private String purpose;
        private String notes;

        AppointmentDetails(String purpose, String notes) {
            this.purpose = purpose;
            this.notes = notes;
        }

        String getDetailsSummary() {
            return "Purpose: " + purpose + ", Notes: " + notes;
        }
    }

    // Method with Object Reference
    public String confirmAppointment(Schedule schedule) throws AppointmentException {
        if (schedule == null || schedule.getScheduleID() != this.scheduleID) {
            throw new AppointmentException("Invalid or mismatched schedule for appointment.");
        }
        if (!"Available".equals(schedule.getStatus())) {
            throw new AppointmentException("Schedule is not available for booking.");
        }
        try {
            schedule.updateStatus("Booked", "Confirmed for appointment " + appointmentID);
            this.status = "Confirmed";
            AppointmentDetails details = new AppointmentDetails("Medical Consultation", "Confirmed by system");
            return "Appointment " + appointmentID + " confirmed for patient " + patientID + ". " + 
                   details.getDetailsSummary();
        } catch (Schedule.InvalidScheduleException e) {
            throw new AppointmentException("Failed to confirm appointment: " + e.getMessage());
        }
    }

    // Method without Object Reference (Static)
    public static String getAppointmentDescription() {
        return "Appointment: Represents a booked slot for a patient with a staff member.";
    }

    // Overloaded Method: Cancel Appointment (Basic)
    public String cancelAppointment() throws AppointmentException {
        if ("Canceled".equals(status)) {
            throw new AppointmentException("Appointment is already canceled.");
        }
        this.status = "Canceled";
        AppointmentDetails details = new AppointmentDetails("N/A", "Canceled by system");
        return "Appointment " + appointmentID + " canceled for patient " + patientID + ". " + 
               details.getDetailsSummary();
    }

    // Overloaded Method: Cancel Appointment (With Reason)
    public String cancelAppointment(String reason) throws AppointmentException {
        if ("Canceled".equals(status)) {
            throw new AppointmentException("Appointment is already canceled.");
        }
        if (reason == null || reason.trim().isEmpty()) {
            throw new AppointmentException("Cancelation reason cannot be empty.");
        }
        this.status = "Canceled";
        AppointmentDetails details = new AppointmentDetails("N/A", "Canceled: " + reason);
        return "Appointment " + appointmentID + " canceled for patient " + patientID + ". " + 
               details.getDetailsSummary();
    }

    // User Defined Exception
    public static class AppointmentException extends Exception {
        public AppointmentException(String message) {
            super(message);
        }
    }

    // Getters and Setters
    public int getAppointmentID() { return appointmentID; }
    public String getPatientID() { return patientID; }
    public int getScheduleID() { return scheduleID; }
    public String getStatus() { return status; }
    public Timestamp getBookingTimestamp() { return bookingTimestamp; }
    public void setStatus(String status) { this.status = validateStatus(status); }

    // Helper Method to Validate Status
    private String validateStatus(String status) {
        if (status == null || !(status.equals("Pending") || status.equals("Confirmed") || 
                                status.equals("Canceled"))) {
            return "Pending"; // Default status
        }
        return status;
    }

    // Override toString
    @Override
    public String toString() {
        AppointmentDetails details = new AppointmentDetails("Medical Consultation", "N/A");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return "Appointment [ID=" + appointmentID + ", PatientID=" + patientID + 
               ", ScheduleID=" + scheduleID + ", Status=" + status + 
               ", BookingTimestamp=" + sdf.format(bookingTimestamp) + 
               ", Details=" + details.getDetailsSummary() + "]";
    }
}