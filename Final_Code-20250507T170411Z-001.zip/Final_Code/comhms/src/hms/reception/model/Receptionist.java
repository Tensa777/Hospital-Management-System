package comhms.src.hms.reception.model;

import comhms.src.hms.auth.model.UserLogin;
import comhms.src.hms.admin.model.Schedule;
import java.util.List;

public class Receptionist extends UserLogin {
    private String deskNumber; // E.g., DSK001

    // Constructor
    public Receptionist(int userID, String username, String password, String name, int age, 
                       String deskNumber) {
        super(userID, username, password, "Receptionist", "Receptionist", name, age, deskNumber, deskNumber);
        this.deskNumber = deskNumber;
    }

    // Overloaded Constructor
    public Receptionist(int userID, String username, String password, String name, int age, 
                       String deskNumber, String securityQuestion, String securityAnswer) {
        super(userID, username, password, "Receptionist", "Receptionist", name, age, 
              securityQuestion, securityAnswer);
        this.deskNumber = deskNumber;
    }

    // Inner Class for Reception Task
    private class ReceptionTask {
        private String taskType;
        private String details;

        ReceptionTask(String taskType, String details) {
            this.taskType = taskType;
            this.details = details;
        }

        String getTaskSummary() {
            return "Task: " + taskType + ", Details: " + details;
        }
    }

    // Method with Object Reference
    public String bookAppointment(Schedule schedule, String patientID) throws ReceptionistAccessException {
        if (schedule == null || patientID == null || patientID.trim().isEmpty()) {
            throw new ReceptionistAccessException("Schedule and patient ID cannot be null or empty.");
        }
        ReceptionTask task = new ReceptionTask("Appointment Booking", "Patient: " + patientID);
        try {
            String result = schedule.updateStatus("Booked", "Booked by receptionist for patient " + patientID);
            return result + "\n" + task.getTaskSummary();
        } catch (Schedule.InvalidScheduleException e) {
            throw new ReceptionistAccessException("Failed to book appointment: " + e.getMessage());
        }
    }

    // Method without Object Reference (Static)
    public static String getReceptionistRoleDescription() {
        return "Receptionist: Manages appointments and patient registrations.";
    }

    // Overloaded Method: Register Patient (Basic)
    public String registerPatient(String patientID, String patientName) throws ReceptionistAccessException {
        if (patientID == null || patientName == null || patientID.trim().isEmpty() || patientName.trim().isEmpty()) {
            throw new ReceptionistAccessException("Patient ID and name cannot be null or empty.");
        }
        ReceptionTask task = new ReceptionTask("Patient Registration", "ID: " + patientID + ", Name: " + patientName);
        return "Patient registered: " + patientName + " (" + patientID + "). " + task.getTaskSummary();
    }

    // Overloaded Method: Register Patient (With Contact)
    public String registerPatient(String patientID, String patientName, String contactInfo) 
            throws ReceptionistAccessException {
        if (patientID == null || patientName == null || contactInfo == null || 
            patientID.trim().isEmpty() || patientName.trim().isEmpty() || contactInfo.trim().isEmpty()) {
            throw new ReceptionistAccessException("Patient ID, name, and contact cannot be null or empty.");
        }
        ReceptionTask task = new ReceptionTask("Patient Registration", 
                                             "ID: " + patientID + ", Name: " + patientName + ", Contact: " + contactInfo);
        return "Patient registered: " + patientName + " (" + patientID + "). " + task.getTaskSummary();
    }

    // Method to View Available Schedules
    public String viewAvailableSchedules(List<Schedule> schedules) throws ReceptionistAccessException {
        if (schedules == null) {
            throw new ReceptionistAccessException("Schedule list cannot be null.");
        }
        StringBuilder result = new StringBuilder("Available Schedules:\n");
        boolean hasAvailable = false;
        for (Schedule schedule : schedules) {
            if ("Available".equals(schedule.getStatus())) {
                result.append(schedule.toString()).append("\n");
                hasAvailable = true;
            }
        }
        if (!hasAvailable) {
            result.append("No available schedules.");
        }
        return result.toString();
    }

    // User Defined Exception
    public static class ReceptionistAccessException extends Exception {
        public ReceptionistAccessException(String message) {
            super(message);
        }
    }

    // Getters and Setters
    public String getDeskNumber() { return deskNumber; }
    public void setDeskNumber(String deskNumber) { this.deskNumber = deskNumber; }

    // Override toString
    @Override
    public String toString() {
        ReceptionTask task = new ReceptionTask("N/A", "N/A");
        return "Receptionist [Username=" + getUsername() + ", DeskNumber=" + deskNumber + 
               ", TaskSummary=" + task.getTaskSummary() + "]";
    }
}