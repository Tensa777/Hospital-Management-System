package comhms.src.hms.reception.view;

import comhms.src.hms.reception.model.Receptionist;
import comhms.src.hms.admin.model.Schedule.InvalidScheduleException;
import comhms.src.hms.auth.controller.UserLoginService;
import java.util.Scanner;

public class ReceptionView {
    private Scanner scanner;
    private Receptionist receptionist;
    private UserLoginService loginService; // For authentication
    private ReceptionService receptionService; // For backend logic

    // Constructor
    public ReceptionView(Receptionist receptionist, UserLoginService loginService) {
        this.scanner = new Scanner(System.in);
        this.receptionist = receptionist;
        this.loginService = loginService;
        this.receptionService = new ReceptionService(loginService); // Placeholder
    }

    // Overloaded Constructor
    public ReceptionView(Receptionist receptionist, UserLoginService loginService, 
                         ReceptionService receptionService) {
        this.scanner = new Scanner(System.in);
        this.receptionist = receptionist;
        this.loginService = loginService;
        this.receptionService = receptionService;
    }

    // Inner Class for Menu Options
    private class MenuOption {
        private String description;
        private Runnable action;

        MenuOption(String description, Runnable action) {
            this.description = description;
            this.action = action;
        }

        void display(int index) {
            System.out.println(index + ". " + description);
        }

        void execute() {
            action.run();
        }
    }

    // Method with Object Reference
    public void displayReceptionMenu(Receptionist receptionist) {
        this.receptionist = receptionist; // Update receptionist reference
        MenuOption[] options = {
            new MenuOption("Book Appointment", this::handleBookAppointment),
            new MenuOption("Register Patient", this::handleRegisterPatient),
            new MenuOption("View Available Schedules", this::handleViewSchedules),
            new MenuOption("Cancel Appointment", this::handleCancelAppointment),
            new MenuOption("Update Profile", this::handleUpdateProfile),
            new MenuOption("Logout", () -> System.out.println("Logging out..."))
        };

        while (true) {
            System.out.println("\n=== Receptionist Dashboard ===");
            System.out.println("Welcome, " + receptionist.getUsername() + " (Receptionist)");
            for (int i = 0; i < options.length; i++) {
                options[i].display(i + 1);
            }

            int choice = getValidChoice(options.length);
            if (choice == options.length) { // Logout
                options[choice - 1].execute();
                break;
            }
            options[choice - 1].execute();
        }
    }

    // Method without Object Reference (Static)
    public static String getWelcomeMessage() {
        return "Welcome to the Receptionist Dashboard!";
    }

    // Handle Book Appointment
    private void handleBookAppointment() {
        try {
            System.out.print("Enter Appointment ID (e.g., 1): ");
            int appointmentID = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter Patient ID (e.g., PAT001): ");
            String patientID = scanner.nextLine();
            System.out.print("Enter Schedule ID (e.g., 1): ");
            int scheduleID = Integer.parseInt(scanner.nextLine());
            String result = receptionService.bookAppointment(receptionist, appointmentID, patientID, scheduleID);
            System.out.println(result);
        } catch (NumberFormatException e) {
            System.out.println("Error: Please enter valid numbers for IDs.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Handle Register Patient
    private void handleRegisterPatient() {
        try {
            System.out.print("Enter Patient ID (e.g., PAT002): ");
            String patientID = scanner.nextLine();
            System.out.print("Enter Patient Name: ");
            String patientName = scanner.nextLine();
            System.out.print("Enter Contact Info (or press Enter to skip): ");
            String contactInfo = scanner.nextLine();
            String result = contactInfo.isEmpty() ? 
                           receptionService.registerPatient(receptionist, patientID, patientName) :
                           receptionService.registerPatient(receptionist, patientID, patientName, contactInfo);
            System.out.println(result);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Handle View Available Schedules
    private void handleViewSchedules() {
        try {
            String schedules = receptionService.viewAvailableSchedules(receptionist);
            System.out.println(schedules);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Handle Cancel Appointment
    private void handleCancelAppointment() {
        try {
            System.out.print("Enter Appointment ID (e.g., 1): ");
            int appointmentID = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter Cancelation Reason (or press Enter to skip): ");
            String reason = scanner.nextLine();
            String result = reason.isEmpty() ? 
                           receptionService.cancelAppointment(receptionist, appointmentID) :
                           receptionService.cancelAppointment(receptionist, appointmentID, reason);
            System.out.println(result);
        } catch (NumberFormatException e) {
            System.out.println("Error: Please enter a valid number for Appointment ID.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Handle Update Profile
    private void handleUpdateProfile() {
        System.out.println("\n=== Update Profile ===");
        System.out.println("1. Update Desk Number");
        System.out.println("2. Back");
        int choice = getValidChoice(2);
        if (choice == 2) return;

        try {
            if (choice == 1) {
                System.out.print("Enter New Desk Number (e.g., DSK002): ");
                String newDeskNumber = scanner.nextLine();
                receptionist.setDeskNumber(newDeskNumber);
                System.out.println("Desk number updated to: " + newDeskNumber);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Helper Method
    private int getValidChoice(int max) {
        while (true) {
            try {
                System.out.print("Enter choice (1-" + max + "): ");
                int choice = Integer.parseInt(scanner.nextLine());
                if (choice >= 1 && choice <= max) {
                    return choice;
                }
                System.out.println("Invalid choice! Try again.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number!");
            }
        }
    }
}

// Placeholder ReceptionService
class ReceptionService {
    private comhms.src.hms.auth.controller.UserLoginService loginService;

    public ReceptionService(comhms.src.hms.auth.controller.UserLoginService loginService) {
        this.loginService = loginService;
    }

    public String bookAppointment(Receptionist receptionist, int appointmentID, String patientID, int scheduleID) 
            throws comhms.src.hms.reception.model.Receptionist.ReceptionistAccessException, 
                   comhms.src.hms.reception.model.Appointment.AppointmentException, InvalidScheduleException {
        comhms.src.hms.admin.model.Schedule schedule = new comhms.src.hms.admin.model.Schedule(
            scheduleID, 2, "2025-05-04 09:00", "2025-05-04 10:00", "Available", "Room 101");
        comhms.src.hms.reception.model.Appointment appointment = new comhms.src.hms.reception.model.Appointment(
            appointmentID, patientID, scheduleID, "Pending");
        return appointment.confirmAppointment(schedule);
    }

    public String registerPatient(Receptionist receptionist, String patientID, String patientName) 
            throws comhms.src.hms.reception.model.Receptionist.ReceptionistAccessException {
        return receptionist.registerPatient(patientID, patientName);
    }

    public String registerPatient(Receptionist receptionist, String patientID, String patientName, 
                                 String contactInfo) 
            throws comhms.src.hms.reception.model.Receptionist.ReceptionistAccessException {
        return receptionist.registerPatient(patientID, patientName, contactInfo);
    }

    public String viewAvailableSchedules(Receptionist receptionist) 
            throws comhms.src.hms.reception.model.Receptionist.ReceptionistAccessException, InvalidScheduleException {
        return receptionist.viewAvailableSchedules(java.util.Arrays.asList(
            new comhms.src.hms.admin.model.Schedule(1, 2, "2025-05-04 09:00", "2025-05-04 10:00", 
                                            "Available", "Room 101")));
    }

    public String cancelAppointment(Receptionist receptionist, int appointmentID) 
            throws comhms.src.hms.reception.model.Appointment.AppointmentException {
        comhms.src.hms.reception.model.Appointment appointment = new comhms.src.hms.reception.model.Appointment(
            appointmentID, "PAT001", 1, "Confirmed");
        return appointment.cancelAppointment();
    }

    public String cancelAppointment(Receptionist receptionist, int appointmentID, String reason) 
            throws comhms.src.hms.reception.model.Appointment.AppointmentException {
        comhms.src.hms.reception.model.Appointment appointment = new comhms.src.hms.reception.model.Appointment(
            appointmentID, "PAT001", 1, "Confirmed");
        return appointment.cancelAppointment(reason);
    }
}