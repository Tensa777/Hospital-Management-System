package comhms.src.hms.reception.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class ReceptionTaskLogger {
    private List<LogEntry> logDatabase; // Simulated log storage

    // Constructor
    public ReceptionTaskLogger() {
        this.logDatabase = new ArrayList<>();
    }

    // Overloaded Constructor
    public ReceptionTaskLogger(List<LogEntry> initialLogs) {
        this.logDatabase = initialLogs != null ? initialLogs : new ArrayList<>();
    }

    // Inner Class for Log Entry
    public class LogEntry {
        private int logID;
        private String taskType; // E.g., "Book Appointment", "Register Patient"
        private int receptionistID;
        private String details; // E.g., "Appointment ID: 1, Patient: PAT001"
        private Timestamp timestamp;

        public LogEntry(int logID, String taskType, int receptionistID, String details) {
            this.logID = logID;
            this.taskType = taskType;
            this.receptionistID = receptionistID;
            this.details = details;
            this.timestamp = new Timestamp(System.currentTimeMillis());
        }

        public String getLogDetails() {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return "Log [ID=" + logID + ", Task=" + taskType + ", ReceptionistID=" + receptionistID + 
                   ", Details=" + details + ", Timestamp=" + sdf.format(timestamp) + "]";
        }
    }

    // Method with Object Reference
    public void logTask(String taskType, int receptionistID, String details) 
            throws ReceptionTaskLoggerException {
        if (taskType == null || taskType.trim().isEmpty() || details == null || details.trim().isEmpty()) {
            throw new ReceptionTaskLoggerException("Task type and details cannot be null or empty.");
        }
        int logID = logDatabase.size() + 1; // Simple incremental ID
        LogEntry entry = new LogEntry(logID, taskType, receptionistID, details);
        logDatabase.add(entry);
    }

    // Method without Object Reference (Static)
    public static String getLoggerDescription() {
        return "ReceptionTaskLogger: Logs receptionist tasks with timestamps and details.";
    }

    // Overloaded Method: Retrieve Logs (All)
    public String getLogs() {
        StringBuilder result = new StringBuilder("Reception Task Logs:\n");
        if (logDatabase.isEmpty()) {
            result.append("No logs found.");
        } else {
            for (LogEntry entry : logDatabase) {
                result.append(entry.getLogDetails()).append("\n");
            }
        }
        return result.toString();
    }

    // Overloaded Method: Retrieve Logs (By Receptionist ID)
    public String getLogs(int receptionistID) {
        StringBuilder result = new StringBuilder("Reception Task Logs for Receptionist " + 
                                                receptionistID + ":\n");
        boolean hasLogs = false;
        for (LogEntry entry : logDatabase) {
            if (entry.receptionistID == receptionistID) {
                result.append(entry.getLogDetails()).append("\n");
                hasLogs = true;
            }
        }
        if (!hasLogs) {
            result.append("No logs found for Receptionist " + receptionistID + ".");
        }
        return result.toString();
    }

    // User Defined Exception
    public static class ReceptionTaskLoggerException extends Exception {
        public ReceptionTaskLoggerException(String message) {
            super(message);
        }
    }

    // Getter for Testing
    public List<LogEntry> getLogDatabase() {
        return new ArrayList<>(logDatabase); // Return a copy to protect encapsulation
    }
}