package comhms.src.hms.admin.controller;

import comhms.src.hms.admin.model.Admin;
import comhms.src.hms.admin.model.Schedule;
import comhms.src.hms.auth.model.UserLogin;
import comhms.src.hms.auth.model.AuditLog;
import comhms.src.hms.auth.controller.UserLoginService;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class AdminService {
    private List<Schedule> scheduleDatabase; // Simulated Schedule table
    private UserLoginService loginService; // For user and audit log operations
    private int nextScheduleID;

    // Constructor
    public AdminService(UserLoginService loginService) {
        this.scheduleDatabase = new ArrayList<>();
        this.loginService = loginService;
        this.nextScheduleID = 1;
        initializeDefaultSchedules();
    }

    // Overloaded Constructor
    public AdminService(UserLoginService loginService, List<Schedule> initialSchedules) {
        this.scheduleDatabase = initialSchedules != null ? initialSchedules : new ArrayList<>();
        this.loginService = loginService;
        this.nextScheduleID = initialSchedules != null ? initialSchedules.size() + 1 : 1;
    }

    // Inner Class for Admin Operation Result
    private class OperationResult {
        private boolean success;
        private String message;

        OperationResult(boolean success, String message) {
            this.success = success;
            this.message = message;
        }

        String getMessage() {
            return message;
        }
    }

    // Method with Object Reference
    public OperationResult createSchedule(Admin admin, Schedule schedule) throws Admin.AdminAccessException {
        if (!admin.isSuperAdmin()) {
            throw new Admin.AdminAccessException("Only super admins can create schedules.");
        }
        scheduleDatabase.add(schedule);
        nextScheduleID++;
        return new OperationResult(true, "Schedule created: " + schedule);
    }

    // Method without Object Reference (Static)
    public static String getServiceDescription() {
        return "AdminService: Manages schedules, users, and audit logs for the Admin module.";
    }

    // Overloaded Method: Update Schedule Status
    public String updateScheduleStatus(Admin admin, int scheduleID, String newStatus) 
            throws Admin.AdminAccessException, Schedule.InvalidScheduleException {
        if (!admin.isSuperAdmin()) {
            throw new Admin.AdminAccessException("Only super admins can update schedules.");
        }
        Schedule schedule = getScheduleByID(scheduleID);
        return schedule.updateStatus(newStatus);
    }

    // Overloaded Method: Update Schedule Status with Reason
    public String updateScheduleStatus(Admin admin, int scheduleID, String newStatus, String reason) 
            throws Admin.AdminAccessException, Schedule.InvalidScheduleException {
        if (!admin.isSuperAdmin()) {
            throw new Admin.AdminAccessException("Only super admins can update schedules.");
        }
        Schedule schedule = getScheduleByID(scheduleID);
        return schedule.updateStatus(newStatus, reason);
    }

    // Method to Manage User (Activate/Deactivate)
    public String manageUser(Admin admin, String userID, boolean activate) 
            throws Admin.AdminAccessException, UserLoginService.InvalidUserIDException {
        UserLogin user = loginService.getUserByID(userID);
        return admin.manageUser(user, activate);
    }

    // Method to Manage User (Update Role)
    public String manageUser(Admin admin, String userID, String newRole) 
            throws Admin.AdminAccessException, UserLoginService.InvalidUserIDException {
        UserLogin user = loginService.getUserByID(userID);
        return admin.manageUser(user, newRole);
    }

    // Method to Get Audit Logs
    public List<AuditLog> getAuditLogs(Admin admin) throws Admin.AdminAccessException {
        return loginService.getAuditLogs();
    }

    // Method to Get Schedule by ID
    public Schedule getScheduleByID(int scheduleID) throws Schedule.InvalidScheduleException {
        for (Schedule schedule : scheduleDatabase) {
            if (schedule.getScheduleID() == scheduleID) {
                return schedule;
            }
        }
        throw new Schedule.InvalidScheduleException("Schedule ID " + scheduleID + " not found.");
    }

    // Method to Get Next Schedule ID
    public int getNextScheduleID() {
        return nextScheduleID;
    }

    // Method to Add Schedule (For Testing)
    public void addSchedule(Schedule schedule) {
        scheduleDatabase.add(schedule);
        nextScheduleID++;
    }

    // User Defined Exception
    public static class AdminServiceException extends Exception {
        public AdminServiceException(String message) {
            super(message);
        }
    }

    // Private Helper Method
    private void initializeDefaultSchedules() {
        try {
            Schedule schedule = new Schedule(nextScheduleID, 2, "2025-05-04 09:00", 
                                            "2025-05-04 10:00", "Available", "Room 101");
            scheduleDatabase.add(schedule);
            nextScheduleID++;
        } catch (Schedule.InvalidScheduleException e) {
            // Ignore for now
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AdminService)) return false;
        AdminService that = (AdminService) o;
        return nextScheduleID == that.nextScheduleID && 
               Objects.equals(scheduleDatabase, that.scheduleDatabase);
    }

    @Override
    public int hashCode() {
        return Objects.hash(scheduleDatabase, nextScheduleID);
    }
}