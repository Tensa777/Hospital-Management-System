package comhms.src.hms.admin.model;

import comhms.src.hms.auth.model.UserLogin;
import comhms.src.hms.auth.model.AuditLog;
import java.util.List;

public class Admin extends UserLogin {
    private String department; // E.g., "Hospital Management"
    private boolean superAdmin; // Extra privileges

    // Constructor
    public Admin(int userID, String username, String password, String name, int age, String department, boolean superAdmin) {
        super(userID, username, password, "Admin", name, age);
        this.department = department;
        this.superAdmin = superAdmin;
    }

    // Overloaded Constructor
    public Admin(int userID, String username, String password, String name, int age, String department, boolean superAdmin, 
                 String securityQuestion, String securityAnswer) {
        super(userID, username, password, "Admin", null, name, age, securityQuestion, securityAnswer);
        this.department = department;
        this.superAdmin = superAdmin;
    }

    // Inner Class for Admin Permissions
    private class Permissions {
        private boolean canManageUsers;
        private boolean canViewAuditLogs;
        private boolean canManageSchedules;

        Permissions(boolean superAdmin) {
            this.canManageUsers = true;
            this.canViewAuditLogs = true;
            this.canManageSchedules = superAdmin; // Only super admins
        }

        String getPermissionSummary() {
            return "Manage Users: " + canManageUsers + ", View Audit Logs: " + canViewAuditLogs + 
                   ", Manage Schedules: " + canManageSchedules;
        }
    }

    // Method with Object Reference
    public String viewAuditLogs(List<AuditLog> logs) throws AdminAccessException {
        Permissions perms = new Permissions(superAdmin);
        if (!perms.canViewAuditLogs) {
            throw new AdminAccessException("Insufficient permissions to view audit logs.");
        }
        StringBuilder result = new StringBuilder("Audit Logs:\n");
        for (AuditLog log : logs) {
            result.append(log.toString()).append("\n");
        }
        return result.toString();
    }

    // Method without Object Reference (Static)
    public static String getAdminRoleDescription() {
        return "Admin: Manages users, schedules, and system reports.";
    }

    // Overloaded Method: Manage User (Activate)
    public String manageUser(UserLogin user, boolean activate) throws AdminAccessException {
        Permissions perms = new Permissions(superAdmin);
        if (!perms.canManageUsers) {
            throw new AdminAccessException("Insufficient permissions to manage users.");
        }
        String status = activate ? "activated" : "deactivated";
        return "User " + user.getUsername() + " has been " + status + ".";
    }

    // Overloaded Method: Manage User (Update Role)
    public String manageUser(UserLogin user, String newRole) throws AdminAccessException {
        Permissions perms = new Permissions(superAdmin);
        if (!perms.canManageUsers) {
            throw new AdminAccessException("Insufficient permissions to manage users.");
        }
        return "User " + user.getUsername() + " role updated to " + newRole + ".";
    }

    // User Defined Exception
    public static class AdminAccessException extends Exception {
        public AdminAccessException(String message) {
            super(message);
        }
    }

    // Getters and Setters
    public String getDepartment() { return department; }
    public boolean isSuperAdmin() { return superAdmin; }
    public void setDepartment(String department) { this.department = department; }
    public void setSuperAdmin(boolean superAdmin) { this.superAdmin = superAdmin; }

    // Override toString
    @Override
    public String toString() {
        Permissions perms = new Permissions(superAdmin);
        return "Admin [Username=" + getUsername() + ", Department=" + department + 
               ", SuperAdmin=" + superAdmin + ", Permissions=" + perms.getPermissionSummary() + "]";
    }
}