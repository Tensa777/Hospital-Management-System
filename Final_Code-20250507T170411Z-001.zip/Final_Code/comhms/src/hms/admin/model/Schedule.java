package comhms.src.hms.admin.model;

import comhms.src.hms.auth.model.UserLogin;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

public class Schedule {
    private int scheduleID;
    private int staffID; // Links to UserLogin.userID
    private Timestamp startTime;
    private Timestamp endTime;
    private String status; // E.g., "Booked", "Available", "Cancelled"
    private String location; // E.g., "Room 101"

    // Constructor
    public Schedule(int scheduleID, int staffID, String startTimeStr, String endTimeStr, String status, String location) 
            throws InvalidScheduleException {
        this.scheduleID = scheduleID;
        this.staffID = staffID;
        this.status = status;
        this.location = location;
        setTime(startTimeStr, endTimeStr);
    }

    // Overloaded Constructor
    public Schedule(int scheduleID, int staffID, Timestamp startTime, Timestamp endTime, String status, String location) 
            throws InvalidScheduleException {
        this.scheduleID = scheduleID;
        this.staffID = staffID;
        this.startTime = startTime;
        this.endTime = endTime;
        this.status = status;
        this.location = location;
        validateTime();
    }

    // Inner Class for Schedule Details
    private class ScheduleDetails {
        private String staffRole;
        private String purpose;

        ScheduleDetails(String staffRole, String purpose) {
            this.staffRole = staffRole;
            this.purpose = purpose;
        }

        String getSummary() {
            return "Role: " + staffRole + ", Purpose: " + purpose;
        }
    }

    // Method with Object Reference
    public boolean assignStaff(UserLogin staff, String role, String purpose) throws InvalidScheduleException {
        if (!status.equals("Available")) {
            throw new InvalidScheduleException("Schedule is not available for assignment.");
        }
        if (staff.getUserID() != this.staffID) {
            throw new InvalidScheduleException("Staff ID does not match schedule.");
        }
        ScheduleDetails details = new ScheduleDetails(role, purpose);
        this.status = "Booked";
        System.out.println("Assigned: " + details.getSummary());
        return true;
    }

    // Method without Object Reference (Static)
    public static String getValidStatusList() {
        return "Available, Booked, Cancelled";
    }

    // Overloaded Method: Update Status
    public String updateStatus(String newStatus) throws InvalidScheduleException {
        if (!isValidStatus(newStatus)) {
            throw new InvalidScheduleException("Invalid status: " + newStatus);
        }
        this.status = newStatus;
        return "Schedule " + scheduleID + " status updated to " + newStatus;
    }

    // Overloaded Method: Update Status with Reason
    public String updateStatus(String newStatus, String reason) throws InvalidScheduleException {
        if (!isValidStatus(newStatus)) {
            throw new InvalidScheduleException("Invalid status: " + newStatus);
        }
        this.status = newStatus;
        return "Schedule " + scheduleID + " status updated to " + newStatus + " (Reason: " + reason + ")";
    }

    // User Defined Exception
    public static class InvalidScheduleException extends Exception {
        public InvalidScheduleException(String message) {
            super(message);
        }
    }

    // Getters and Setters
    public int getScheduleID() { return scheduleID; }
    public int getStaffID() { return staffID; }
    public Timestamp getStartTime() { return startTime; }
    public Timestamp getEndTime() { return endTime; }
    public String getStatus() { return status; }
    public String getLocation() { return location; }

    public void setStaffID(int staffID) { this.staffID = staffID; }
    public void setLocation(String location) { this.location = location; }

    // Private Helper Methods
    private void setTime(String startTimeStr, String endTimeStr) throws InvalidScheduleException {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            Date startDate = sdf.parse(startTimeStr);
            Date endDate = sdf.parse(endTimeStr);
            this.startTime = new Timestamp(startDate.getTime());
            this.endTime = new Timestamp(endDate.getTime());
            validateTime();
        } catch (ParseException e) {
            throw new InvalidScheduleException("Invalid date/time format. Use yyyy-MM-dd HH:mm.");
        }
    }

    private void validateTime() throws InvalidScheduleException {
        if (endTime.before(startTime) || endTime.equals(startTime)) {
            throw new InvalidScheduleException("End time must be after start time.");
        }
    }

    private boolean isValidStatus(String status) {
        return status != null && getValidStatusList().contains(status);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Schedule)) return false;
        Schedule schedule = (Schedule) o;
        return scheduleID == schedule.scheduleID;
    }

    @Override
    public int hashCode() {
        return Objects.hash(scheduleID);
    }

    @Override
    public String toString() {
        return "Schedule [ID=" + scheduleID + ", StaffID=" + staffID + ", Start=" + startTime + 
               ", End=" + endTime + ", Status=" + status + ", Location=" + location + "]";
    }
}