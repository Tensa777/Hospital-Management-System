package comhms.src.hms.admin.view;

import comhms.src.hms.admin.model.Admin;
import comhms.src.hms.admin.model.Schedule;
import comhms.src.hms.auth.controller.UserLoginService;
import comhms.src.hms.auth.model.UserLogin;
import java.util.Scanner;

public class AdminView {
    private Scanner scanner;
    private Admin admin;
    private UserLoginService loginService; // For audit logs and user management
    private AdminService adminService; // Placeholder for schedule management

    // Constructor
    public AdminView(Admin admin, UserLoginService loginService) {
        this.scanner = new Scanner(System.in);
        this.admin = admin;
        this.loginService = loginService;
        this.adminService = new AdminService(); // Placeholder
    }

    // Overloaded Constructor
    public AdminView(Admin admin, UserLoginService loginService, AdminService adminService) {
        this.scanner = new Scanner(System.in);
        this.admin = admin;
        this.loginService = loginService;
        this.adminService = adminService;
    }

    // Inner Class for Menu Options
    private class MenuOption {
        private String description;
        private Runnable action;

        MenuOption(String description, Runnable action) {
            this.description = description;
            this.action = action;
        }

        void display(int index) {
            System.out.println(index + ". " + description);
        }

        void execute() {
            action.run();
        }
    }

    // Method with Object Reference
    public void displayAdminMenu(Admin admin) {
        this.admin = admin; // Update admin reference
        MenuOption[] options = {
            new MenuOption("View Audit Logs", this::handleViewAuditLogs),
            new MenuOption("Manage Users", this::handleManageUsers),
            new MenuOption("Manage Schedules", this::handleManageSchedules),
            new MenuOption("Logout", () -> System.out.println("Logging out..."))
        };

        while (true) {
            System.out.println("\n=== Admin Dashboard ===");
            System.out.println("Welcome, " + admin.getUsername() + " (" + admin.getDepartment() + ")");
            for (int i = 0; i < options.length; i++) {
                options[i].display(i + 1);
            }

            int choice = getValidChoice(options.length);
            if (choice == options.length) { // Logout
                options[choice - 1].execute();
                break;
            }
            options[choice - 1].execute();
        }
    }

    // Method without Object Reference (Static)
    public static String getWelcomeMessage() {
        return "Welcome to the Admin Dashboard!";
    }

    // Handle View Audit Logs
    private void handleViewAuditLogs() {
        try {
            String logs = admin.viewAuditLogs(loginService.getAuditLogs());
            System.out.println(logs);
        } catch (Admin.AdminAccessException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Handle Manage Users
    private void handleManageUsers() {
        System.out.println("\n=== Manage Users ===");
        System.out.println("1. Activate/Deactivate User");
        System.out.println("2. Update User Role");
        System.out.println("3. Back");
        int choice = getValidChoice(3);

        if (choice == 3) return;

        System.out.print("Enter User ID (e.g., AD0001): ");
        String userID = scanner.nextLine();

        try {
            UserLogin user = loginService.getUserByID(userID);
            if (choice == 1) {
                System.out.print("Activate user? (y/n): ");
                boolean activate = scanner.nextLine().trim().toLowerCase().startsWith("y");
                String result = admin.manageUser(user, activate);
                System.out.println(result);
            } else if (choice == 2) {
                System.out.println("Enter new role (Admin, Receptionist, Staff, Patient): ");
                String newRole = scanner.nextLine();
                String result = admin.manageUser(user, newRole);
                System.out.println(result);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Handle Manage Schedules
    private void handleManageSchedules() {
        System.out.println("\n=== Manage Schedules ===");
        System.out.println("1. Create Schedule");
        System.out.println("2. Update Schedule Status");
        System.out.println("3. Back");
        int choice = getValidChoice(3);

        if (choice == 3) return;

        try {
            if (choice == 1) {
                System.out.print("Enter Staff ID (e.g., 2): ");
                int staffID = Integer.parseInt(scanner.nextLine());
                System.out.print("Enter Start Time (yyyy-MM-dd HH:mm): ");
                String startTime = scanner.nextLine();
                System.out.print("Enter End Time (yyyy-MM-dd HH:mm): ");
                String endTime = scanner.nextLine();
                System.out.print("Enter Location (e.g., Room 101): ");
                String location = scanner.nextLine();

                Schedule schedule = new Schedule(adminService.getNextScheduleID(), staffID, startTime, endTime, "Available", location);
                adminService.addSchedule(schedule);
                System.out.println("Schedule created: " + schedule);
            } else if (choice == 2) {
                System.out.print("Enter Schedule ID: ");
                int scheduleID = Integer.parseInt(scanner.nextLine());
                System.out.print("Enter New Status (Available, Booked, Cancelled): ");
                String newStatus = scanner.nextLine();
                System.out.print("Enter Reason (or press Enter to skip): ");
                String reason = scanner.nextLine();

                Schedule schedule = adminService.getScheduleByID(scheduleID);
                String result = reason.isEmpty() ? schedule.updateStatus(newStatus) : schedule.updateStatus(newStatus, reason);
                System.out.println(result);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Helper Method
    private int getValidChoice(int max) {
        while (true) {
            try {
                System.out.print("Enter choice (1-" + max + "): ");
                int choice = Integer.parseInt(scanner.nextLine());
                if (choice >= 1 && choice <= max) {
                    return choice;
                }
                System.out.println("Invalid choice! Try again.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number!");
            }
        }
    }
}

// Placeholder AdminService
class AdminService {
    private int nextScheduleID = 1;

    public int getNextScheduleID() {
        return nextScheduleID++;
    }

    public void addSchedule(Schedule schedule) {
        // Simulate adding to database
        System.out.println("Added to database: " + schedule);
    }

    public Schedule getScheduleByID(int scheduleID) throws Schedule.InvalidScheduleException {
        // Simulate fetching from database
        return new Schedule(scheduleID, 2, "2025-05-04 09:00", "2025-05-04 10:00", "Available", "Room 101");
    }
}