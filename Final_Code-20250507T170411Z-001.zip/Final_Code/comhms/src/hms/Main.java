package comhms.src.hms;

import comhms.src.hms.auth.view.LoginView;
import comhms.src.hms.auth.controller.UserLoginService;
import comhms.src.hms.auth.util.CaptchaValidator;
import comhms.src.hms.auth.util.DashboardRouter;
import comhms.src.hms.auth.model.UserLogin;
import comhms.src.hms.admin.model.Admin;
import comhms.src.hms.reception.model.Receptionist;
import comhms.src.hms.staff.model.Staff;
import comhms.src.hms.patient.model.Patient;
import comhms.src.hms.admin.view.AdminView;
import comhms.src.hms.reception.view.ReceptionView;
import comhms.src.hms.staff.view.StaffView;
import comhms.src.hms.patient.view.PatientView;

public class Main {
    private UserLoginService loginService;
    private CaptchaValidator captchaValidator;
    private LoginView loginView;

    // Constructor
    public Main() {
        DashboardRouter router = new DashboardRouter() {
            @Override
            public void redirect(UserLogin user) {
                System.out.println("Redirecting to " + user.getRole() + " Dashboard...");
                if (user.getRole().equals("Admin")) {
                    Admin admin = new Admin(user.getUserID(), user.getUsername(), 
                                           user.getPassword(), user.getName(), user.getAge(), null, false);
                    AdminView adminView = new AdminView(admin, loginService);
                    adminView.displayAdminMenu(admin);
                } else if (user.getRole().equals("Receptionist")) {
                    Receptionist receptionist = new Receptionist(user.getUserID(), user.getUsername(), 
                                                               user.getPassword(), user.getName(), 
                                                               user.getAge(), 
                                                               "DSK" + String.format("%03d", user.getUserID()));
                    ReceptionView receptionView = new ReceptionView(receptionist, loginService);
                    receptionView.displayReceptionMenu(receptionist);
                } else if (user.getRole().equals("Staff")) {
                    Staff staff = new Staff(user.getUserID(), user.getUsername(), user.getPassword(), 
                                           user.getName(), null, user.getAge(), 
                                           "STF" + String.format("%03d", user.getUserID()), 
                                           "General", null);
                    StaffView staffView = new StaffView(staff, loginService);
                    staffView.displayStaffMenu(staff);
                } else if (user.getRole().equals("Patient")) {
                    Patient patient = new Patient(user.getUserID(), user.getUsername(), 
                                                user.getPassword(), user.getName(), 
                                                user.getAge(), 
                                                "PAT" + String.format("%03d", user.getUserID()), 
                                                "No medical history provided");
                    PatientView patientView = new PatientView(patient, loginService);
                    patientView.displayPatientMenu(patient);
                }
            }
        };
        this.loginService = new UserLoginService(router);
        this.captchaValidator = new CaptchaValidator();
        this.loginView = new LoginView(loginService, captchaValidator);
    }

    // Overloaded Constructor
    public Main(UserLoginService loginService, CaptchaValidator captchaValidator, 
                LoginView loginView) {
        this.loginService = loginService;
        this.captchaValidator = captchaValidator;
        this.loginView = loginView;
    }

    // Inner Class for System Info
    private class SystemInfo {
        private String version;
        private String description;

        SystemInfo(String version, String description) {
            this.version = version;
            this.description = description;
        }

        String getSystemSummary() {
            return "HMS Version: " + version + ", Description: " + description;
        }
    }

    // Method with Object Reference
    public void startSystem(UserLoginService loginService) {
        SystemInfo info = new SystemInfo("1.0.0", "Hospital Management System");
        System.out.println(info.getSystemSummary());
        this.loginService = loginService;
        loginView.displayLoginMenu(loginService);
    }

    // Method without Object Reference (Static)
    public static String getSystemWelcomeMessage() {
        return "Welcome to the Hospital Management System!";
    }

    // Main Method
    public static void main(String[] args) {
        try {
            Main hms = new Main();
            hms.startSystem(new UserLoginService());
        } catch (Exception e) {
            System.out.println("System Error: " + e.getMessage());
        }
    }

    // Getter for Testing
    public LoginView getLoginView() {
        return loginView;
    }
}